﻿namespace Modbus_CommPro
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_OpenPort = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_SlaveAdd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmb_Paud = new System.Windows.Forms.ComboBox();
            this.cmb_Parity = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmb_PortNum = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_ClosePort = new System.Windows.Forms.Button();
            this.cmb_StopBits = new System.Windows.Forms.ComboBox();
            this.cmb_DataBits = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_data8 = new System.Windows.Forms.TextBox();
            this.txt_data7 = new System.Windows.Forms.TextBox();
            this.txt_data6 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_data5 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_data4 = new System.Windows.Forms.TextBox();
            this.txt_data3 = new System.Windows.Forms.TextBox();
            this.txt_data2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_WriteReg = new System.Windows.Forms.Button();
            this.txt_data1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_ReadReg = new System.Windows.Forms.Button();
            this.btn_WriteBool = new System.Windows.Forms.Button();
            this.txt_data10 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_data9 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_ReadBool = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_OpenPort
            // 
            this.btn_OpenPort.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_OpenPort.Location = new System.Drawing.Point(283, 112);
            this.btn_OpenPort.Margin = new System.Windows.Forms.Padding(4);
            this.btn_OpenPort.Name = "btn_OpenPort";
            this.btn_OpenPort.Size = new System.Drawing.Size(87, 33);
            this.btn_OpenPort.TabIndex = 0;
            this.btn_OpenPort.Text = "打开串口";
            this.btn_OpenPort.UseVisualStyleBackColor = true;
            this.btn_OpenPort.Click += new System.EventHandler(this.btn_OpenPort_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "从站地址：";
            // 
            // txt_SlaveAdd
            // 
            this.txt_SlaveAdd.Location = new System.Drawing.Point(117, 27);
            this.txt_SlaveAdd.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SlaveAdd.Name = "txt_SlaveAdd";
            this.txt_SlaveAdd.Size = new System.Drawing.Size(75, 29);
            this.txt_SlaveAdd.TabIndex = 2;
            this.txt_SlaveAdd.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "波特率：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 123);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "校验位：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(243, 72);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 21);
            this.label4.TabIndex = 5;
            this.label4.Text = "数据位：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 166);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 21);
            this.label5.TabIndex = 6;
            this.label5.Text = "停止位：";
            // 
            // cmb_Paud
            // 
            this.cmb_Paud.FormattingEnabled = true;
            this.cmb_Paud.Location = new System.Drawing.Point(117, 72);
            this.cmb_Paud.Name = "cmb_Paud";
            this.cmb_Paud.Size = new System.Drawing.Size(75, 29);
            this.cmb_Paud.TabIndex = 7;
            // 
            // cmb_Parity
            // 
            this.cmb_Parity.FormattingEnabled = true;
            this.cmb_Parity.Location = new System.Drawing.Point(117, 119);
            this.cmb_Parity.Name = "cmb_Parity";
            this.cmb_Parity.Size = new System.Drawing.Size(75, 29);
            this.cmb_Parity.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmb_PortNum);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.btn_ClosePort);
            this.groupBox1.Controls.Add(this.cmb_StopBits);
            this.groupBox1.Controls.Add(this.cmb_DataBits);
            this.groupBox1.Controls.Add(this.cmb_Parity);
            this.groupBox1.Controls.Add(this.cmb_Paud);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btn_OpenPort);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txt_SlaveAdd);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(18, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(429, 211);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "通讯参数";
            // 
            // cmb_PortNum
            // 
            this.cmb_PortNum.FormattingEnabled = true;
            this.cmb_PortNum.Location = new System.Drawing.Point(324, 28);
            this.cmb_PortNum.Name = "cmb_PortNum";
            this.cmb_PortNum.Size = new System.Drawing.Size(87, 29);
            this.cmb_PortNum.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(243, 31);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 21);
            this.label11.TabIndex = 14;
            this.label11.Text = "串口号：";
            // 
            // btn_ClosePort
            // 
            this.btn_ClosePort.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ClosePort.Location = new System.Drawing.Point(283, 160);
            this.btn_ClosePort.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ClosePort.Name = "btn_ClosePort";
            this.btn_ClosePort.Size = new System.Drawing.Size(87, 33);
            this.btn_ClosePort.TabIndex = 13;
            this.btn_ClosePort.Text = "关闭串口";
            this.btn_ClosePort.UseVisualStyleBackColor = true;
            this.btn_ClosePort.Click += new System.EventHandler(this.btn_ClosePort_Click);
            // 
            // cmb_StopBits
            // 
            this.cmb_StopBits.FormattingEnabled = true;
            this.cmb_StopBits.Location = new System.Drawing.Point(117, 163);
            this.cmb_StopBits.Name = "cmb_StopBits";
            this.cmb_StopBits.Size = new System.Drawing.Size(75, 29);
            this.cmb_StopBits.TabIndex = 11;
            // 
            // cmb_DataBits
            // 
            this.cmb_DataBits.FormattingEnabled = true;
            this.cmb_DataBits.Location = new System.Drawing.Point(324, 68);
            this.cmb_DataBits.Name = "cmb_DataBits";
            this.cmb_DataBits.Size = new System.Drawing.Size(87, 29);
            this.cmb_DataBits.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_data8);
            this.groupBox2.Controls.Add(this.txt_data7);
            this.groupBox2.Controls.Add(this.txt_data6);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txt_data5);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txt_data4);
            this.groupBox2.Controls.Add(this.txt_data3);
            this.groupBox2.Controls.Add(this.txt_data2);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.btn_WriteReg);
            this.groupBox2.Controls.Add(this.txt_data1);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btn_ReadReg);
            this.groupBox2.Controls.Add(this.btn_WriteBool);
            this.groupBox2.Controls.Add(this.txt_data10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txt_data9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.btn_ReadBool);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(18, 228);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(429, 284);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "数据测试";
            // 
            // txt_data8
            // 
            this.txt_data8.Location = new System.Drawing.Point(281, 146);
            this.txt_data8.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data8.Name = "txt_data8";
            this.txt_data8.Size = new System.Drawing.Size(59, 29);
            this.txt_data8.TabIndex = 35;
            // 
            // txt_data7
            // 
            this.txt_data7.Location = new System.Drawing.Point(281, 109);
            this.txt_data7.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data7.Name = "txt_data7";
            this.txt_data7.Size = new System.Drawing.Size(59, 29);
            this.txt_data7.TabIndex = 34;
            // 
            // txt_data6
            // 
            this.txt_data6.Location = new System.Drawing.Point(281, 72);
            this.txt_data6.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data6.Name = "txt_data6";
            this.txt_data6.Size = new System.Drawing.Size(59, 29);
            this.txt_data6.TabIndex = 29;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(183, 149);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 21);
            this.label14.TabIndex = 33;
            this.label14.Text = "线圈00007：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(183, 112);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 21);
            this.label15.TabIndex = 32;
            this.label15.Text = "线圈00006：";
            // 
            // txt_data5
            // 
            this.txt_data5.Location = new System.Drawing.Point(281, 35);
            this.txt_data5.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data5.Name = "txt_data5";
            this.txt_data5.Size = new System.Drawing.Size(59, 29);
            this.txt_data5.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(183, 75);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 21);
            this.label16.TabIndex = 30;
            this.label16.Text = "线圈00005：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(183, 38);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(103, 21);
            this.label17.TabIndex = 28;
            this.label17.Text = "线圈00004：";
            // 
            // txt_data4
            // 
            this.txt_data4.Location = new System.Drawing.Point(117, 146);
            this.txt_data4.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data4.Name = "txt_data4";
            this.txt_data4.Size = new System.Drawing.Size(59, 29);
            this.txt_data4.TabIndex = 26;
            // 
            // txt_data3
            // 
            this.txt_data3.Location = new System.Drawing.Point(117, 109);
            this.txt_data3.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data3.Name = "txt_data3";
            this.txt_data3.Size = new System.Drawing.Size(59, 29);
            this.txt_data3.TabIndex = 27;
            // 
            // txt_data2
            // 
            this.txt_data2.Location = new System.Drawing.Point(117, 72);
            this.txt_data2.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data2.Name = "txt_data2";
            this.txt_data2.Size = new System.Drawing.Size(59, 29);
            this.txt_data2.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 149);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 21);
            this.label13.TabIndex = 25;
            this.label13.Text = "线圈00003：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 21);
            this.label12.TabIndex = 24;
            this.label12.Text = "线圈00002：";
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(2, 191);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(427, 2);
            this.label10.TabIndex = 23;
            // 
            // btn_WriteReg
            // 
            this.btn_WriteReg.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_WriteReg.Location = new System.Drawing.Point(324, 242);
            this.btn_WriteReg.Margin = new System.Windows.Forms.Padding(4);
            this.btn_WriteReg.Name = "btn_WriteReg";
            this.btn_WriteReg.Size = new System.Drawing.Size(73, 29);
            this.btn_WriteReg.TabIndex = 22;
            this.btn_WriteReg.Text = "写入";
            this.btn_WriteReg.UseVisualStyleBackColor = true;
            this.btn_WriteReg.Click += new System.EventHandler(this.btn_WriteReg_Click);
            // 
            // txt_data1
            // 
            this.txt_data1.Location = new System.Drawing.Point(117, 35);
            this.txt_data1.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data1.Name = "txt_data1";
            this.txt_data1.Size = new System.Drawing.Size(59, 29);
            this.txt_data1.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 21);
            this.label6.TabIndex = 20;
            this.label6.Text = "线圈00001：";
            // 
            // btn_ReadReg
            // 
            this.btn_ReadReg.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ReadReg.Location = new System.Drawing.Point(324, 204);
            this.btn_ReadReg.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ReadReg.Name = "btn_ReadReg";
            this.btn_ReadReg.Size = new System.Drawing.Size(73, 29);
            this.btn_ReadReg.TabIndex = 19;
            this.btn_ReadReg.Text = "读取";
            this.btn_ReadReg.UseVisualStyleBackColor = true;
            this.btn_ReadReg.Click += new System.EventHandler(this.btn_ReadReg_Click);
            // 
            // btn_WriteBool
            // 
            this.btn_WriteBool.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_WriteBool.Location = new System.Drawing.Point(349, 70);
            this.btn_WriteBool.Margin = new System.Windows.Forms.Padding(4);
            this.btn_WriteBool.Name = "btn_WriteBool";
            this.btn_WriteBool.Size = new System.Drawing.Size(73, 29);
            this.btn_WriteBool.TabIndex = 18;
            this.btn_WriteBool.Text = "写入";
            this.btn_WriteBool.UseVisualStyleBackColor = true;
            this.btn_WriteBool.Click += new System.EventHandler(this.btn_WriteBool_Click);
            // 
            // txt_data10
            // 
            this.txt_data10.Location = new System.Drawing.Point(169, 241);
            this.txt_data10.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data10.Name = "txt_data10";
            this.txt_data10.Size = new System.Drawing.Size(104, 29);
            this.txt_data10.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 245);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 21);
            this.label9.TabIndex = 16;
            this.label9.Text = "寄存器40003：";
            // 
            // txt_data9
            // 
            this.txt_data9.Location = new System.Drawing.Point(169, 204);
            this.txt_data9.Margin = new System.Windows.Forms.Padding(4);
            this.txt_data9.Name = "txt_data9";
            this.txt_data9.Size = new System.Drawing.Size(104, 29);
            this.txt_data9.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 21);
            this.label8.TabIndex = 14;
            this.label8.Text = "寄存器40001：";
            // 
            // btn_ReadBool
            // 
            this.btn_ReadBool.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ReadBool.Location = new System.Drawing.Point(349, 35);
            this.btn_ReadBool.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ReadBool.Name = "btn_ReadBool";
            this.btn_ReadBool.Size = new System.Drawing.Size(73, 29);
            this.btn_ReadBool.TabIndex = 13;
            this.btn_ReadBool.Text = "读取";
            this.btn_ReadBool.UseVisualStyleBackColor = true;
            this.btn_ReadBool.Click += new System.EventHandler(this.btn_ReadBool_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 21);
            this.label7.TabIndex = 11;
            this.label7.Text = "线圈00000：";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 531);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modbus-RTU";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_OpenPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_SlaveAdd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmb_Paud;
        private System.Windows.Forms.ComboBox cmb_Parity;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_WriteReg;
        private System.Windows.Forms.TextBox txt_data1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_ReadReg;
        private System.Windows.Forms.Button btn_WriteBool;
        private System.Windows.Forms.TextBox txt_data10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_data9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_ReadBool;
        private System.Windows.Forms.TextBox txt_data2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmb_StopBits;
        private System.Windows.Forms.ComboBox cmb_DataBits;
        private System.Windows.Forms.Button btn_ClosePort;
        private System.Windows.Forms.ComboBox cmb_PortNum;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_data8;
        private System.Windows.Forms.TextBox txt_data7;
        private System.Windows.Forms.TextBox txt_data6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_data5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_data4;
        private System.Windows.Forms.TextBox txt_data3;
    }
}

