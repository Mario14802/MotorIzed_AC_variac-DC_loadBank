﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modbus_CommPro
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();          
            this.Load += FrmMain_Load;
        }


        //创建Modbus实体类
        Modbus objMod;
        //定义从站地址
        int iDevAdd;


        /// <summary>
        /// 窗口初始化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void FrmMain_Load(object sender, EventArgs e)
        {
            //第一步：初始化串口参数
            InitialPort();
            //第二步：创建Modbus通讯对象
            objMod = new Modbus();
        }

        /// <summary>
        /// 初始化参数
        /// </summary>
        private void InitialPort()
        {
            this.cmb_Paud.Items.Add("4800");
            this.cmb_Paud.Items.Add("9600");
            this.cmb_Paud.Items.Add("14400");
            this.cmb_Paud.Items.Add("19200");
            this.cmb_Paud.Items.Add("38400");
            this.cmb_Paud.SelectedIndex = 1;
            for (int i = 0; i < 10; i++)
            {
                this.cmb_PortNum.Items.Add("COM" + i.ToString());
            }
            this.cmb_PortNum.SelectedIndex = 3;
            this.cmb_DataBits.Items.Add("7");
            this.cmb_DataBits.Items.Add("8");
            this.cmb_DataBits.SelectedIndex = 1;
            this.cmb_Parity.Items.Add("奇校验");
            this.cmb_Parity.Items.Add("偶校验");
            this.cmb_Parity.Items.Add("无校验");
            this.cmb_Parity.SelectedIndex = 2;
            this.cmb_StopBits.Items.Add("1");
            this.cmb_StopBits.Items.Add("2");
            this.cmb_StopBits.SelectedIndex = 0;

        }

        /// <summary>
        /// 打开串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_OpenPort_Click(object sender, EventArgs e)
        {
            //第一步：串口参数数据转化
            string strPortNo = this.cmb_PortNum.Text.Trim();

            int iBaudRate = Convert.ToInt32(this.cmb_Paud.Text.Trim());

            int iDataBits = Convert.ToInt32(this.cmb_DataBits.Text.Trim());

            Parity iParity;
            StopBits iStopBits;
            switch (this.cmb_Parity.Text.Trim())
            {
                case "奇校验": iParity = Parity.Odd; break;
                case "偶校验": iParity = Parity.Even; break;
                case "无校验": iParity = Parity.None; break;
                default:
                    iParity = Parity.None;
                    break;
            }
            switch (this.cmb_StopBits.Text.Trim())
            {
                case "1":
                    iStopBits = StopBits.One;
                    break;
                case "2":
                    iStopBits = StopBits.Two;
                    break;
                default:
                    iStopBits = StopBits.One;
                    break;
            }

            iDevAdd = Convert.ToInt32(this.txt_SlaveAdd.Text.Trim());

            //第二步：调用Modbus对象的打开串口方法
            bool Res = objMod.OpenMyCom(strPortNo, iBaudRate, iDataBits, iParity, iStopBits);
            if (Res)
            {
                MessageBox.Show("打开串口成功!");
            }
            else
            {
                MessageBox.Show("打开串口失败!");
            }
        }

        /// <summary>
        /// 读取00001、00002
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ReadBool_Click(object sender, EventArgs e)
        {
            //初始化参数
            long iAddress = 0;
            int iLength = 8;
            //调用方法
            byte[] Res = objMod.ReadOutputStatus(iDevAdd, iAddress, iLength);
            //解析数据
            if (Res != null)
            {
                string ByteStr = Convert.ToInt32(Convert.ToString(Convert.ToInt32(Res[0]), 2)).ToString("0#######");
                this.txt_data1.Text = ByteStr.Substring(7, 1);
                this.txt_data2.Text = ByteStr.Substring(6, 1);
                this.txt_data3.Text = ByteStr.Substring(5, 1);
                this.txt_data4.Text = ByteStr.Substring(4, 1);
                this.txt_data5.Text = ByteStr.Substring(3, 1);
                this.txt_data6.Text = ByteStr.Substring(2, 1);
                this.txt_data7.Text = ByteStr.Substring(1, 1);
                this.txt_data8.Text = ByteStr.Substring(0, 1);
            }
        }

        /// <summary>
        /// 写入00001、00002
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_WriteBool_Click(object sender, EventArgs e)
        {
            //第一位
            if (this.txt_data1.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 0);
            }
            else if (this.txt_data1.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 0);
            }
            //第二位
            if (this.txt_data2.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 1);
            }
            else if (this.txt_data2.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 1);
            }
            //第三位
            if (this.txt_data3.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 2);
            }
            else if (this.txt_data3.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 2);
            }
            //第四位
            if (this.txt_data4.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 3);
            }
            else if (this.txt_data4.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 3);
            }
            //第五位
            if (this.txt_data5.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 4);
            }
            else if (this.txt_data5.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 4);
            }
            //第六位
            if (this.txt_data6.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 5);
            }
            else if (this.txt_data6.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 5);
            }
            //第七位
            if (this.txt_data7.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 6);
            }
            else if (this.txt_data7.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 6);
            }
            //第八位
            if (this.txt_data8.Text.Trim() == "1")
            {
                objMod.ForceOn(iDevAdd, 7);
            }
            else if (this.txt_data8.Text.Trim() == "0")
            {
                objMod.ForceOff(iDevAdd, 7);
            }
         
        }

        /// <summary>
        /// 读取40001-40002
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ReadReg_Click(object sender, EventArgs e)
        {
            //初始化参数
            long iAddress = 0;
            int iLength = 4;
            //调用方法
            byte[] Res = objMod.ReadKeepReg(iDevAdd, iAddress, iLength);
            //解析数据
            if (Res != null)
            {
                byte[] res1 = new byte[4] { Res[0], Res[1], Res[2], Res[3] };
               // res1 = Reverse(res1);
                this.txt_data9.Text =BytetoFloatByPoint(res1).ToString("f2");

                byte[] res2 = new byte[4] { Res[4], Res[5], Res[6], Res[7] };
             //   res2 = Reverse(res2);
                this.txt_data10.Text = Convert.ToDouble(BytetoFloatByPoint(res2)).ToString("f1");
            }
        }

        /// <summary>
        /// 写入40001、40002
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_WriteReg_Click(object sender, EventArgs e)
        {       
            //初始化参数
            float data1 = Convert.ToSingle(this.txt_data9.Text.Trim());
            float data2 = Convert.ToSingle(this.txt_data10.Text.Trim());
            objMod.PreSetFloatKeepReg(iDevAdd, 0, data1);
            objMod.PreSetFloatKeepReg(iDevAdd, 2, data2);
        }

        #region 报文转换
        /// <summary>
        /// 调换寄存器位置
        /// </summary>
        /// <param name="buff"></param>
        /// <returns></returns>
        private byte[] Reverse(byte[] buff)
        {
            byte[] res = new byte[buff.Length];
            if (buff.Length == 4)
            {
                res[0] = buff[2];
                res[1] = buff[3];
                res[2] = buff[0];
                res[3] = buff[1];
            }
            return res;
        }


        #endregion

        #region 将字节数组转换为浮点型
        public float BytetoFloatByPoint(byte[] bResponse)
        {

            //uint nRest = ((uint)response[startByte]) * 256 + ((uint)response[startByte + 1]) + 65536 * ((uint)response[startByte + 2]) * 256 + ((uint)response[startByte + 3]);
            float fValue = 0f;
            uint nRest = ((uint)bResponse[2]) * 256
                + ((uint)bResponse[3]) +
                65536 * (((uint)bResponse[0]) * 256 + ((uint)bResponse[1]));
            //用指针将整形强制转换成float
            unsafe
            {
                float* ptemp;
                ptemp = (float*)(&nRest);
                fValue = *ptemp;
            }
            return fValue;
        }
        #endregion

        /// <summary>
        /// 关闭串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ClosePort_Click(object sender, EventArgs e)
        {
            bool Res = objMod.CloseMyCom();
            if (Res)
            {
                MessageBox.Show("关闭串口成功!");
            }
            else
            {
                MessageBox.Show("串口未打开!");
            }
        }

    }
}
