﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.IO;

namespace powerTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//开启多线程控制
        string LogPath = "";
        Thread threadTest1;
        CheckBox[] checks = new CheckBox[20];//单选框组
        ComboBox[] ModelCB = new ComboBox[20];//模式下拉框组
        ComboBox[] VolCB = new ComboBox[20];//电压下拉框组
        ComboBox[] CurCB = new ComboBox[20]; //电流下拉框组
        Label[] TempL = new Label[20];//温度
        Label[] VolL = new Label[20];//电压
        Label[] CurL = new Label[20];//电流
        Label[] PowerL = new Label[20];//功率
        Label[] CapL = new Label[20];//容量
        Label[] WHL = new Label[20];//瓦时
        Label[] WorkTime = new Label[20];//工作时间
        bool[] setflags = new bool[20]; //设定开关标记
        string[] cjdz = new string[20]; //转换后的从机地址
        bool status = false;
        bool StartWrite = false;

        SerialPort sp = new SerialPort();
        private void Form1_Load(object sender, EventArgs e)
        {
            threadTest1 = new Thread(ThreadTest);
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//开启跨线程访问控件
            //单选框赋值
            checks[0] = checkBox1; checks[1] = checkBox2; checks[2] = checkBox3; checks[3] = checkBox4; checks[4] = checkBox5;
            checks[5] = checkBox6; checks[6] = checkBox7; checks[7] = checkBox8; checks[8] = checkBox9; checks[9] = checkBox10;
            checks[10] = checkBox11; checks[11] = checkBox12; checks[12] = checkBox13; checks[13] = checkBox14; checks[14] = checkBox15;
            checks[15] = checkBox16; checks[16] = checkBox17; checks[17] = checkBox18; checks[18] = checkBox19; checks[19] = checkBox20;

            //模式下拉框组赋值
            ModelCB[0] = comboBox1; ModelCB[1] = comboBox2; ModelCB[2] = comboBox3; ModelCB[3] = comboBox4; ModelCB[4] = comboBox5;
            ModelCB[5] = comboBox6; ModelCB[6] = comboBox7; ModelCB[7] = comboBox8; ModelCB[8] = comboBox9; ModelCB[9] = comboBox10;
            ModelCB[10] = comboBox11; ModelCB[11] = comboBox12; ModelCB[12] = comboBox13; ModelCB[13] = comboBox14; ModelCB[14] = comboBox15;
            ModelCB[15] = comboBox16; ModelCB[16] = comboBox17; ModelCB[17] = comboBox18; ModelCB[18] = comboBox19; ModelCB[19] = comboBox20;

            //电压下拉框组
            VolCB[0] = comboBox21; VolCB[1] = comboBox22; VolCB[2] = comboBox23; VolCB[3] = comboBox24; VolCB[4] = comboBox25;
            VolCB[5] = comboBox26; VolCB[6] = comboBox27; VolCB[7] = comboBox28; VolCB[8] = comboBox29; VolCB[9] = comboBox30;
            VolCB[10] = comboBox31; VolCB[11] = comboBox32; VolCB[12] = comboBox33; VolCB[13] = comboBox34; VolCB[14] = comboBox35;
            VolCB[15] = comboBox36; VolCB[16] = comboBox37; VolCB[17] = comboBox38; VolCB[18] = comboBox39; VolCB[19] = comboBox40;

            //电流下拉框组
            CurCB[0] = comboBox41; CurCB[1] = comboBox42; CurCB[2] = comboBox43; CurCB[3] = comboBox44; CurCB[4] = comboBox45;
            CurCB[5] = comboBox46; CurCB[6] = comboBox47; CurCB[7] = comboBox48; CurCB[8] = comboBox49; CurCB[9] = comboBox50;
            CurCB[10] = comboBox51; CurCB[11] = comboBox52; CurCB[12] = comboBox53; CurCB[13] = comboBox54; CurCB[14] = comboBox55;
            CurCB[15] = comboBox56; CurCB[16] = comboBox57; CurCB[17] = comboBox58; CurCB[18] = comboBox59; CurCB[19] = comboBox60;

            //温度
            TempL[0] = label1; TempL[1] = label2; TempL[2] = label3; TempL[3] = label4; TempL[4] = label5;
            TempL[5] = label6; TempL[6] = label7; TempL[7] = label8; TempL[8] = label9; TempL[9] = label10;
            TempL[10] = label11; TempL[11] = label12; TempL[12] = label13; TempL[13] = label14; TempL[14] = label15;
            TempL[15] = label16; TempL[16] = label17; TempL[17] = label18; TempL[18] = label19; TempL[19] = label20;

            //电压
            VolL[0] = label21; VolL[1] = label22; VolL[2] = label23; VolL[3] = label24; VolL[4] = label25;
            VolL[5] = label26; VolL[6] = label27; VolL[7] = label28; VolL[8] = label29; VolL[9] = label30;
            VolL[10] = label31; VolL[11] = label32; VolL[12] = label33; VolL[13] = label34; VolL[14] = label35;
            VolL[15] = label36; VolL[16] = label37; VolL[17] = label38; VolL[18] = label39; VolL[19] = label40;

            //电流
            CurL[0] = label41; CurL[1] = label42; CurL[2] = label43; CurL[3] = label44; CurL[4] = label45;
            CurL[5] = label46; CurL[6] = label47; CurL[7] = label48; CurL[8] = label49; CurL[9] = label50;
            CurL[10] = label51; CurL[11] = label52; CurL[12] = label53; CurL[13] = label54; CurL[14] = label55;
            CurL[15] = label56; CurL[16] = label57; CurL[17] = label58; CurL[18] = label59; CurL[19] = label60;

            //功率
            PowerL[0] = label61; PowerL[1] = label62; PowerL[2] = label63; PowerL[3] = label64; PowerL[4] = label65;
            PowerL[5] = label66; PowerL[6] = label67; PowerL[7] = label68; PowerL[8] = label69; PowerL[9] = label70;
            PowerL[10] = label71; PowerL[11] = label72; PowerL[12] = label73; PowerL[13] = label74; PowerL[14] = label75;
            PowerL[15] = label76; PowerL[16] = label77; PowerL[17] = label78; PowerL[18] = label79; PowerL[19] = label80;

            //容量
            CapL[0] = label81; CapL[1] = label82; CapL[2] = label83; CapL[3] = label84; CapL[4] = label85;
            CapL[5] = label86; CapL[6] = label87; CapL[7] = label88; CapL[8] = label89; CapL[9] = label90;
            CapL[10] = label91; CapL[11] = label92; CapL[12] = label93; CapL[13] = label94; CapL[14] = label95;
            CapL[15] = label96; CapL[16] = label97; CapL[17] = label98; CapL[18] = label99; CapL[19] = label100;

            //瓦时
            WHL[0] = label101; WHL[1] = label102; WHL[2] = label103; WHL[3] = label104; WHL[4] = label105;
            WHL[5] = label106; WHL[6] = label107; WHL[7] = label108; WHL[8] = label109; WHL[9] = label110;
            WHL[10] = label111; WHL[11] = label112; WHL[12] = label113; WHL[13] = label114; WHL[14] = label115;
            WHL[15] = label116; WHL[16] = label117; WHL[17] = label118; WHL[18] = label119; WHL[19] = label120;

            //工作时间
            WorkTime[0] = label121; WorkTime[1] = label122; WorkTime[2] = label123; WorkTime[3] = label124; WorkTime[4] = label125;
            WorkTime[5] = label126; WorkTime[6] = label127; WorkTime[7] = label128; WorkTime[8] = label129; WorkTime[9] = label130;
            WorkTime[10] = label131; WorkTime[11] = label132; WorkTime[12] = label133; WorkTime[13] = label134; WorkTime[14] = label135;
            WorkTime[15] = label136; WorkTime[16] = label137; WorkTime[17] = label138; WorkTime[18] = label139; WorkTime[19] = label140;

            checkBoxAllS.Enabled = false;
            for (int i = 0; i < setflags.Length; i++)
            {
                cjdz[i] = (i + 1).ToString("X2");//从机地址赋值
                setflags[i] = false;//初始化标记
                TempL[i].Text = "...";
                VolL[i].Text = "...";
                CurL[i].Text = "...";
                PowerL[i].Text = "...";
                CapL[i].Text = "...";
                WHL[i].Text = "...";
                WorkTime[i].Text = "...";
                checks[i].Enabled = false;
                //VolCB[i].p
            }
            // string[] ports = SerialPort.GetPortNames();//获取当前可用串口号
            comboBox_serialport.Items.AddRange(SerialPort.GetPortNames());
            comboBox_serialport.Text = Properties.Settings.Default.P_SPort; //读取上次记录
            LogPath = Properties.Settings.Default.setPath;
            if (LogPath == "")
            {
                LogPath = Directory.GetCurrentDirectory() + @"\LogPath";
            }

            buttonStart.Enabled = false;
            buttonPath.Enabled = false;
            // timerAuto.Enabled = false;
        }
        DateTime lasttime = DateTime.Now.AddHours(-1);
        void ThreadTest()
        {
            while (true)
            {
                this.Text = "电源测试  当前时间:" + DateTime.Now + "- 上一轮测试时间:" + lasttime + "= 时间间隔 :( " + (DateTime.Now - lasttime).Seconds + " ) s";

                if (DateTime.Now > lasttime.AddSeconds(20))
                {
                    lasttime = DateTime.Now;
                    Thread.Sleep(1000);
                    status = true;
                    int timetick = 1000;
                    int tickcount = 1;
                    for (int i = 0; i < checks.Length; i++)
                    {

                        if (checks[i].Checked)  //判断选中
                        {
                            tickcount++;
                        }
                    }
                    status = false;
                    for (int i = 0; i < checks.Length; i++)
                    {

                        if (checks[i].Checked)  //判断选中
                        {
                            status = true;
                            break;
                        }
                    }

                    button_OpenSerial.Enabled = status ? false : true;
                    buttonStart.Enabled = status ? true : false;
                    buttonPath.Enabled = status ? true : false;

                    timetick = timetick / tickcount;

                    timerAuto.Enabled = false;

                    for (int i = 0; i < checks.Length; i++)
                    {

                        double loadTemp = 0;
                        double dy = 0;
                        double dl = 0;
                        double power = 0;
                        double capacity = 0;
                        double watt = 0;
                        double duration = 0;
                        buttonStart.Text = StartWrite ? (i + 1) + "/" + checks.Length : "开始测试";

                        if (checks[i].Checked)  //判断选中
                        {
                            if (setflags[i])//设定标记已经设定则读取数据
                            {
                                byte[] dudyf = CRC.strModBusCRCbyte16(cjdz[i] + "040003000A");//读取信息   ,  命令: 1.从机地址1byte    2.功能码1byte     3.地址2byte  4 数量2byte
                                sp.Write(dudyf, 0, dudyf.Length);
                                InfoOut("->" + nSerial.BytesToString(dudyf));
                                Thread.Sleep(150);
                                byte[] dudy = new byte[sp.BytesToRead]; //报文:1.从机地址1byte   2.功能码1byte  
                                sp.Read(dudy, 0, dudy.Length);

                                InfoOut("<-" + nSerial.BytesToString(dudy));
                                if (dudy.Length > 0)
                                {
                                    try
                                    {
                                        loadTemp = ((dudy[3] << 8) + dudy[4]);
                                        dy = ((dudy[9] << 8) + dudy[10]) / 100.00;
                                        dl = ((dudy[11] << 8) + dudy[12]) / 1000.00;
                                        power = ((dudy[13] << 8) + dudy[14]) / 100.0;
                                        capacity = ((dudy[17] << 8) + dudy[18]);
                                        watt = ((dudy[19] << 8) + dudy[20]) / 100.0;
                                        duration = ((dudy[21] << 8) + dudy[22]);

                                        VolL[i].Text = dy.ToString();
                                        CurL[i].Text = dl.ToString();
                                        TempL[i].Text = loadTemp.ToString();
                                        PowerL[i].Text = power.ToString();
                                        CapL[i].Text = capacity.ToString();
                                        WHL[i].Text = watt.ToString();
                                        WorkTime[i].Text = duration.ToString();
                                    }
                                    catch
                                    {
                                        VolL[i].Text = "-1";
                                        CurL[i].Text = "-1";
                                    }
                                }
                                else
                                {
                                    VolL[i].Text = "Unused";
                                    CurL[i].Text = "Unused";
                                }
                            }
                            else
                            {
                                VolL[i].Text = "setting...";
                                CurL[i].Text = "setting...";

                                byte[] moshif = CRC.strModBusCRCbyte16(cjdz[i] + "0600010001");//模式设置
                                sp.Write(moshif, 0, moshif.Length);
                                InfoOut(nSerial.BytesToString(moshif));

                                for (int a = 0; a < 100; a++)
                                {
                                    Thread.Sleep(1);
                                    Application.DoEvents();
                                }
                                byte[] moshi = new byte[sp.BytesToRead];
                                sp.Read(moshi, 0, moshi.Length);
                                InfoOut(nSerial.BytesToString(moshi));

                                string setA = Convert.ToInt32((Convert.ToDouble(CurCB[i].Text.Trim()) * 1000)).ToString("X4");//读取数据转换16进制
                                byte[] setdlf = CRC.strModBusCRCbyte16(cjdz[i] + "060004" + setA);//设置电流, 实际电流*1000转换
                                sp.Write(setdlf, 0, setdlf.Length);
                                InfoOut(nSerial.BytesToString(setdlf));

                                for (int a = 0; a < 100; a++)
                                {
                                    Thread.Sleep(1);
                                    Application.DoEvents();
                                }
                                byte[] setdl = new byte[sp.BytesToRead];
                                sp.Read(setdl, 0, setdl.Length);

                                InfoOut(nSerial.BytesToString(setdl));

                                byte[] setkjf = CRC.strModBusCRCbyte16(cjdz[i] + "0600020001");//开机
                                sp.Write(setkjf, 0, setkjf.Length);
                                InfoOut(nSerial.BytesToString(setkjf));

                                for (int a = 0; a < 100; a++)
                                {
                                    Thread.Sleep(1);
                                    Application.DoEvents();
                                }
                                byte[] setkj = new byte[sp.BytesToRead];
                                sp.Read(setkj, 0, setkj.Length);
                                InfoOut(nSerial.BytesToString(setkj));
                                setflags[i] = true; //已经设定标记
                            }
                        }
                        else //关机
                        {
                            VolL[i].Text = "...";
                            CurL[i].Text = "...";
                            TempL[i].Text = "...";
                            PowerL[i].Text = "...";
                            CapL[i].Text = "...";
                            WHL[i].Text = "...";
                            WorkTime[i].Text = "...";

                            setflags[i] = false; //已经设定标记
                        }


                    }
                    if (StartWrite)//采集开关打开状态
                    {
                        string logline = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        for (int i = 0; i < checks.Length; i++)
                        {
                            if (VolL[i].Text == "setting...")
                            {
                                logline = "";
                                break;
                            }

                            string vol = VolL[i].Text == "Unused" || VolL[i].Text == "..." ? "0" : VolL[i].Text;
                            string cur = CurL[i].Text == "Unused" || CurL[i].Text == "..." ? "0" : CurL[i].Text;
                            logline += "," + vol + "," + cur;
                        }
                        if (logline != "")
                        {
                            WriteLog(logline);//待加条件判断
                        }
                    }
                }
                Thread.Sleep(200);
            }
        }
        private void QuitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void CheckBoxAllS_CheckedChanged(object sender, EventArgs e)
        {//全选复选框
            if (checkBoxAllS.Checked)
            {
                for (int i = 0; i < checks.Length; i++)
                {
                    checks[i].Checked = true;
                }
            }
            else
            {
                for (int i = 0; i < checks.Length; i++)
                {
                    checks[i].Checked = false;
                }
            }
        }

        private void ComboBox_serialport_SelectedIndexChanged(object sender, EventArgs e)
        {
            //保存串口号
            Properties.Settings.Default.P_SPort = comboBox_serialport.Text; //记录当前选择
            Properties.Settings.Default.Save();
        }

        private void Button_OpenSerial_Click(object sender, EventArgs e)
        {
            //打开端口
            if (!sp.IsOpen)
            {
                sp.PortName = comboBox_serialport.Text;
                sp.BaudRate = Convert.ToInt32(comboBox_BaudRate.Text.Trim());
                sp.DataBits = Convert.ToInt32(comboBox_DataBits.Text.Trim());
                sp.Parity = Parity.None;
                sp.StopBits = StopBits.One;
                sp.Open();
                button_OpenSerial.Text = "关闭串口";
                checkBoxAllS.Enabled = true;
                //  timerAuto.Enabled = true;
                for (int i = 0; i < setflags.Length; i++)
                {
                    checks[i].Enabled = true;
                }
                threadTest1.Start();
            }
            else
            {
                sp.Close();
                button_OpenSerial.Text = "打开串口";
                //timerAuto.Enabled = false;
                checkBoxAllS.Enabled = false;
                for (int i = 0; i < setflags.Length; i++)
                {
                    checks[i].Enabled = false;
                }

            }
        }

        private void TimerAuto_Tick(object sender, EventArgs e)
        {
            status = true;
            int timetick = 1000;
            int tickcount = 1;
            for (int i = 0; i < checks.Length; i++)
            {

                if (checks[i].Checked)  //判断选中
                {
                    tickcount++;
                }
            }
            status = false;
            for (int i = 0; i < checks.Length; i++)
            {

                if (checks[i].Checked)  //判断选中
                {
                    status = true;
                    break;
                }
            }

            button_OpenSerial.Enabled = status ? false : true;
            buttonStart.Enabled = status ? true : false;
            buttonPath.Enabled = status ? true : false;

            timetick = timetick / tickcount;

            timerAuto.Enabled = false;

            for (int i = 0; i < checks.Length; i++)
            {

                double loadTemp = 0;
                double dy = 0;
                double dl = 0;
                double power = 0;
                double capacity = 0;
                double watt = 0;
                double duration = 0;
                buttonStart.Text = StartWrite ? (i + 1) + "/" + checks.Length : "开始测试";

                if (checks[i].Checked)  //判断选中
                {
                    if (setflags[i])//设定标记已经设定则读取数据
                    {
                        byte[] dudyf = CRC.strModBusCRCbyte16(cjdz[i] + "040003000A");//读取信息   ,  命令: 1.从机地址1byte    2.功能码1byte     3.地址2byte  4 数量2byte
                        sp.Write(dudyf, 0, dudyf.Length);
                        InfoOut(nSerial.BytesToString(dudyf));
                        for (int a = 0; a < 150; a++)
                        {
                            Thread.Sleep(1);
                            Application.DoEvents();
                        }
                        byte[] dudy = new byte[sp.BytesToRead]; //报文:1.从机地址1byte   2.功能码1byte  
                        sp.Read(dudy, 0, dudy.Length);
                        InfoOut(nSerial.BytesToString(dudy));
                        if (dudy.Length > 0)
                        {
                            try
                            {
                                loadTemp = ((dudy[3] << 8) + dudy[4]);
                                dy = ((dudy[9] << 8) + dudy[10]) / 100.00;
                                dl = ((dudy[11] << 8) + dudy[12]) / 1000.00;
                                power = ((dudy[13] << 8) + dudy[14]) / 100.0;
                                capacity = ((dudy[17] << 8) + dudy[18]);
                                watt = ((dudy[19] << 8) + dudy[20]) / 100.0;
                                duration = ((dudy[21] << 8) + dudy[22]);

                                VolL[i].Text = dy.ToString();
                                CurL[i].Text = dl.ToString();
                                TempL[i].Text = loadTemp.ToString();
                                PowerL[i].Text = power.ToString();
                                CapL[i].Text = capacity.ToString();
                                WHL[i].Text = watt.ToString();
                                WorkTime[i].Text = duration.ToString();
                            }
                            catch
                            {
                                VolL[i].Text = "-1";
                                CurL[i].Text = "-1";
                            }
                        }
                        else
                        {
                            VolL[i].Text = "Unused";
                            CurL[i].Text = "Unused";
                        }
                    }
                    else
                    {
                        VolL[i].Text = "setting...";
                        CurL[i].Text = "setting...";

                        byte[] moshif = CRC.strModBusCRCbyte16(cjdz[i] + "0600010001");//模式设置
                        sp.Write(moshif, 0, moshif.Length);
                        InfoOut(nSerial.BytesToString(moshif));

                        for (int a = 0; a < 100; a++)
                        {
                            Thread.Sleep(1);
                            Application.DoEvents();
                        }
                        byte[] moshi = new byte[sp.BytesToRead];
                        sp.Read(moshi, 0, moshi.Length);
                        InfoOut(nSerial.BytesToString(moshi));

                        string setA = Convert.ToInt32((Convert.ToDouble(CurCB[i].Text.Trim()) * 1000)).ToString("X4");//读取数据转换16进制
                        byte[] setdlf = CRC.strModBusCRCbyte16(cjdz[i] + "060004" + setA);//设置电流, 实际电流*1000转换
                        sp.Write(setdlf, 0, setdlf.Length);
                        InfoOut(nSerial.BytesToString(setdlf));

                        for (int a = 0; a < 100; a++)
                        {
                            Thread.Sleep(1);
                            Application.DoEvents();
                        }
                        byte[] setdl = new byte[sp.BytesToRead];
                        sp.Read(setdl, 0, setdl.Length);

                        InfoOut(nSerial.BytesToString(setdl));

                        byte[] setkjf = CRC.strModBusCRCbyte16(cjdz[i] + "0600020001");//开机
                        sp.Write(setkjf, 0, setkjf.Length);
                        InfoOut(nSerial.BytesToString(setkjf));

                        for (int a = 0; a < 100; a++)
                        {
                            Thread.Sleep(1);
                            Application.DoEvents();
                        }
                        byte[] setkj = new byte[sp.BytesToRead];
                        sp.Read(setkj, 0, setkj.Length);
                        InfoOut(nSerial.BytesToString(setkj));
                        setflags[i] = true; //已经设定标记
                    }
                }
                else //关机
                {
                    VolL[i].Text = "...";
                    CurL[i].Text = "...";
                    TempL[i].Text = "...";
                    PowerL[i].Text = "...";
                    CapL[i].Text = "...";
                    WHL[i].Text = "...";
                    WorkTime[i].Text = "...";

                    setflags[i] = false; //已经设定标记
                }


            }
            if (StartWrite)//采集开关打开状态
            {
                string logline = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                for (int i = 0; i < checks.Length; i++)
                {
                    if (VolL[i].Text == "setting...")
                    {
                        logline = "";
                        break;
                    }

                    string vol = VolL[i].Text == "Unused" || VolL[i].Text == "..." ? "0" : VolL[i].Text;
                    string cur = CurL[i].Text == "Unused" || CurL[i].Text == "..." ? "0" : CurL[i].Text;
                    logline += "," + vol + "," + cur;
                }
                if (logline != "")
                {
                    WriteLog(logline);//待加条件判断
                }

            }
            if (sp.IsOpen)
            {
                timerAuto.Enabled = true;
            }

        }
        private void WriteLog(string msg)
        {
            string logPath = LogPath + "\\" + DateTime.Now.ToString("yyyyMMdd") + "\\";
            if (!Directory.Exists(logPath)) { Directory.CreateDirectory(logPath); }
            File.AppendAllText(logPath + DateTime.Now.ToString("yyyyMMdd") + "_DataLog.csv", msg + "\r\n");
        }

        private void InfoOut(string msg)
        {
            this.Text = "电源测试  " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + msg;
            listBox1.Items.Insert(0, DateTime.Now.ToString("HH:mm:ss") + " " + msg);

            string logPath = LogPath + "\\" + DateTime.Now.ToString("yyyyMMdd") + "\\";
            if (!Directory.Exists(logPath)) { Directory.CreateDirectory(logPath); }
            File.AppendAllText(logPath + DateTime.Now.ToString("yyyyMMdd") + "_RunLog.log", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + msg + "\r\n");

        }

        private void ButtonStart_Click(object sender, EventArgs e) //点击开始测试
        {
            string logPath = LogPath + "\\" + DateTime.Now.ToString("yyyyMMdd") + "\\";
            string logFullName = logPath + DateTime.Now.ToString("yyyyMMdd") + "_DataLog.csv";
            if (!File.Exists(logFullName))
            {
                string HeadInfo = "time,V1,C1,V2,C2,V3,C3,V4,C4,V5,C5,V6,C6,V7,C7,V8,C8,V9,C9,V10,C10,V11,C11,V12,C12,V13,C13,V14,C14,V15,C15,V16,C16,V17,C17,V18,C18,V19,C19,V20,C20";
                if (!Directory.Exists(logPath)) { Directory.CreateDirectory(logPath); }
                //创建并写入文件头
                File.AppendAllText(logPath + DateTime.Now.ToString("yyyyMMdd") + "_DataLog.csv", HeadInfo + "\r\n");//创建并写入文件头
            }
            StartWrite = StartWrite ? false : true;
            buttonStart.Text = StartWrite ? "关闭测试" : "开始测试";

        }

        private void ButtonPath_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folder = new FolderBrowserDialog();
            folder.ShowDialog();
        }
    }
}
