﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    /// <summary>
    ///  Cyclic Redundancy Check 循环沉余效验
    /// </summary>
    class CRC
    {
        public static int ModBusCRC16(byte[] buff, int Polynomial = 0xA001)
        {
            int CRCvalue = 0xffff;
            for (int i = 0; i < buff.Length; i++)
            {
                CRCvalue = buff[i] ^ CRCvalue;
                for (int b = 0; b < 8; b++)
                {
                    CRCvalue = CRCvalue % 2 == 1 ? ((CRCvalue - 0x1) / 2) ^ Polynomial : CRCvalue / 2;
                }
            }
            return CRCvalue;
        }

        public static byte[] ModBusCRCbyte16(byte[] buff, int Polynomial = 0xA001)
        {

            byte[] rebuff = new byte[buff.Length + 2];
            int CRCvalue = 0xffff;
            for (int i = 0; i < buff.Length; i++)
            {
                CRCvalue = buff[i] ^ CRCvalue;
                for (int b = 0; b < 8; b++)
                {
                    CRCvalue = CRCvalue % 2 == 1 ? ((CRCvalue - 0x1) / 2) ^ Polynomial : CRCvalue / 2;
                }
            }
            buff.CopyTo(rebuff, 0);
            int b1 = (CRCvalue >> 8) & 0xff;
            int b2 = (CRCvalue & 0xff);

            rebuff[rebuff.Length - 1] = (byte)b1;
            rebuff[rebuff.Length - 2] = (byte)b2;
            return rebuff;
        }
        public static byte[] strModBusCRCbyte16(string str16, int Polynomial = 0xA001)
        {
            if (str16.Length % 2 == 1)
            {
                str16 = "0" + str16;//補足位數
            }
            byte[] buff = new byte[str16.Length / 2];
            for (int i = 0; i < buff.Length; i++)
            {
                buff[i] = (byte)Convert.ToInt32(str16.Substring(i * 2, 2), 16);
            }
            byte[] rebuff = new byte[buff.Length + 2];
            int CRCvalue = 0xffff;
            for (int i = 0; i < buff.Length; i++)
            {
                CRCvalue = buff[i] ^ CRCvalue;
                for (int b = 0; b < 8; b++)
                {
                    CRCvalue = CRCvalue % 2 == 1 ? ((CRCvalue - 0x1) / 2) ^ Polynomial : CRCvalue / 2;
                }
            }
            buff.CopyTo(rebuff, 0);
            int b1 = (CRCvalue >> 8) & 0xff;
            int b2 = (CRCvalue & 0xff);

            rebuff[rebuff.Length - 1] = (byte)b1;
            rebuff[rebuff.Length - 2] = (byte)b2;
            return rebuff;
        }
        public static byte[] strModBusCRCbyte16_backup(string str16, int Polynomial = 0xA001)
        {
            if (str16.Length % 2 == 1)
            {
                str16 = "0" + str16;//補足位數
            }
            byte[] buff = new byte[str16.Length / 2];
            for (int i = 0; i < buff.Length; i++)
            {
                buff[i] = (byte)Convert.ToInt32(str16.Substring(i * 2, 2), 16);
            }
            byte[] rebuff = new byte[buff.Length + 2];
            int CRCvalue = 0xffff;
            for (int i = 0; i < buff.Length; i++)
            {
                CRCvalue = buff[i] ^ CRCvalue;
                for (int b = 0; b < 8; b++)
                {
                    CRCvalue = CRCvalue % 2 == 1 ? ((CRCvalue - 0x1) / 2) ^ Polynomial : CRCvalue / 2;
                }
            }
            buff.CopyTo(rebuff, 0);
            int b1 = (CRCvalue >> 8) & 0xff;
            int b2 = (CRCvalue & 0xff);

            rebuff[rebuff.Length - 1] = (byte)b1;
            rebuff[rebuff.Length - 2] = (byte)b2;
            return rebuff;
        }
    }

    public class nSerial
    {
        public static string BytesToString(byte[] buff)
        {
            string bufsrt = "";
            foreach (byte buf in buff)
            {
                bufsrt += buf.ToString("X2");
            }
            return bufsrt;
        }
    }


