﻿namespace powerTest
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_OpenSerial = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.label_chuank = new System.Windows.Forms.Label();
            this.comboBox_StopBit = new System.Windows.Forms.ComboBox();
            this.label_botelv = new System.Windows.Forms.Label();
            this.label_xiaoyanwei = new System.Windows.Forms.Label();
            this.comboBox_DataBits = new System.Windows.Forms.ComboBox();
            this.label_shujuwei = new System.Windows.Forms.Label();
            this.comboBox_serialport = new System.Windows.Forms.ComboBox();
            this.comboBox_BaudRate = new System.Windows.Forms.ComboBox();
            this.comboBox_Parity = new System.Windows.Forms.ComboBox();
            this.labeltingzhiwei = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxAllS = new System.Windows.Forms.CheckBox();
            this.labelsdgggt = new System.Windows.Forms.Label();
            this.labelghj = new System.Windows.Forms.Label();
            this.labelasdffg = new System.Windows.Forms.Label();
            this.labesdasd = new System.Windows.Forms.Label();
            this.comboBox21 = new System.Windows.Forms.ComboBox();
            this.comboBox41 = new System.Windows.Forms.ComboBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label141 = new System.Windows.Forms.Label();
            this.labeliuioui = new System.Windows.Forms.Label();
            this.labeliopiyu = new System.Windows.Forms.Label();
            this.labelvbcbg = new System.Windows.Forms.Label();
            this.labelgfhjgyu = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labeldfgdf = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.comboBox22 = new System.Windows.Forms.ComboBox();
            this.comboBox23 = new System.Windows.Forms.ComboBox();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.comboBox27 = new System.Windows.Forms.ComboBox();
            this.comboBox28 = new System.Windows.Forms.ComboBox();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.comboBox30 = new System.Windows.Forms.ComboBox();
            this.comboBox31 = new System.Windows.Forms.ComboBox();
            this.comboBox32 = new System.Windows.Forms.ComboBox();
            this.comboBox33 = new System.Windows.Forms.ComboBox();
            this.comboBox34 = new System.Windows.Forms.ComboBox();
            this.comboBox35 = new System.Windows.Forms.ComboBox();
            this.comboBox36 = new System.Windows.Forms.ComboBox();
            this.comboBox37 = new System.Windows.Forms.ComboBox();
            this.comboBox38 = new System.Windows.Forms.ComboBox();
            this.comboBox39 = new System.Windows.Forms.ComboBox();
            this.comboBox40 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.comboBox42 = new System.Windows.Forms.ComboBox();
            this.comboBox43 = new System.Windows.Forms.ComboBox();
            this.comboBox44 = new System.Windows.Forms.ComboBox();
            this.comboBox45 = new System.Windows.Forms.ComboBox();
            this.comboBox46 = new System.Windows.Forms.ComboBox();
            this.comboBox47 = new System.Windows.Forms.ComboBox();
            this.comboBox48 = new System.Windows.Forms.ComboBox();
            this.comboBox49 = new System.Windows.Forms.ComboBox();
            this.comboBox50 = new System.Windows.Forms.ComboBox();
            this.comboBox51 = new System.Windows.Forms.ComboBox();
            this.comboBox52 = new System.Windows.Forms.ComboBox();
            this.comboBox53 = new System.Windows.Forms.ComboBox();
            this.comboBox54 = new System.Windows.Forms.ComboBox();
            this.comboBox55 = new System.Windows.Forms.ComboBox();
            this.comboBox56 = new System.Windows.Forms.ComboBox();
            this.comboBox57 = new System.Windows.Forms.ComboBox();
            this.comboBox58 = new System.Windows.Forms.ComboBox();
            this.comboBox59 = new System.Windows.Forms.ComboBox();
            this.comboBox60 = new System.Windows.Forms.ComboBox();
            this.labelfghhhj = new System.Windows.Forms.Label();
            this.timerAuto = new System.Windows.Forms.Timer(this.components);
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonPath = new System.Windows.Forms.Button();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_OpenSerial
            // 
            this.button_OpenSerial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_OpenSerial.Location = new System.Drawing.Point(718, 26);
            this.button_OpenSerial.Name = "button_OpenSerial";
            this.button_OpenSerial.Size = new System.Drawing.Size(79, 23);
            this.button_OpenSerial.TabIndex = 5;
            this.button_OpenSerial.Text = "打开串口";
            this.button_OpenSerial.UseVisualStyleBackColor = true;
            this.button_OpenSerial.Click += new System.EventHandler(this.Button_OpenSerial_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonStart.Location = new System.Drawing.Point(801, 26);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(79, 23);
            this.buttonStart.TabIndex = 5;
            this.buttonStart.Text = "开始测试";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.ButtonStart_Click);
            // 
            // label_chuank
            // 
            this.label_chuank.AutoSize = true;
            this.label_chuank.Location = new System.Drawing.Point(3, 25);
            this.label_chuank.Name = "label_chuank";
            this.label_chuank.Size = new System.Drawing.Size(29, 12);
            this.label_chuank.TabIndex = 0;
            this.label_chuank.Text = "串口";
            // 
            // comboBox_StopBit
            // 
            this.comboBox_StopBit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_StopBit.FormattingEnabled = true;
            this.comboBox_StopBit.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBox_StopBit.Location = new System.Drawing.Point(411, 21);
            this.comboBox_StopBit.Name = "comboBox_StopBit";
            this.comboBox_StopBit.Size = new System.Drawing.Size(34, 20);
            this.comboBox_StopBit.TabIndex = 1;
            this.comboBox_StopBit.Text = "1";
            // 
            // label_botelv
            // 
            this.label_botelv.AutoSize = true;
            this.label_botelv.Location = new System.Drawing.Point(86, 25);
            this.label_botelv.Name = "label_botelv";
            this.label_botelv.Size = new System.Drawing.Size(41, 12);
            this.label_botelv.TabIndex = 0;
            this.label_botelv.Text = "波特率";
            // 
            // label_xiaoyanwei
            // 
            this.label_xiaoyanwei.AutoSize = true;
            this.label_xiaoyanwei.Location = new System.Drawing.Point(193, 25);
            this.label_xiaoyanwei.Name = "label_xiaoyanwei";
            this.label_xiaoyanwei.Size = new System.Drawing.Size(41, 12);
            this.label_xiaoyanwei.TabIndex = 0;
            this.label_xiaoyanwei.Text = "检验位";
            // 
            // comboBox_DataBits
            // 
            this.comboBox_DataBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_DataBits.FormattingEnabled = true;
            this.comboBox_DataBits.Items.AddRange(new object[] {
            "6",
            "7",
            "8"});
            this.comboBox_DataBits.Location = new System.Drawing.Point(332, 21);
            this.comboBox_DataBits.Name = "comboBox_DataBits";
            this.comboBox_DataBits.Size = new System.Drawing.Size(32, 20);
            this.comboBox_DataBits.TabIndex = 1;
            this.comboBox_DataBits.Text = "8";
            // 
            // label_shujuwei
            // 
            this.label_shujuwei.AutoSize = true;
            this.label_shujuwei.Location = new System.Drawing.Point(288, 25);
            this.label_shujuwei.Name = "label_shujuwei";
            this.label_shujuwei.Size = new System.Drawing.Size(41, 12);
            this.label_shujuwei.TabIndex = 0;
            this.label_shujuwei.Text = "数据位";
            // 
            // comboBox_serialport
            // 
            this.comboBox_serialport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_serialport.FormattingEnabled = true;
            this.comboBox_serialport.Location = new System.Drawing.Point(35, 21);
            this.comboBox_serialport.Name = "comboBox_serialport";
            this.comboBox_serialport.Size = new System.Drawing.Size(48, 20);
            this.comboBox_serialport.TabIndex = 1;
            this.comboBox_serialport.SelectedIndexChanged += new System.EventHandler(this.ComboBox_serialport_SelectedIndexChanged);
            // 
            // comboBox_BaudRate
            // 
            this.comboBox_BaudRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_BaudRate.FormattingEnabled = true;
            this.comboBox_BaudRate.Items.AddRange(new object[] {
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "25600"});
            this.comboBox_BaudRate.Location = new System.Drawing.Point(130, 21);
            this.comboBox_BaudRate.Name = "comboBox_BaudRate";
            this.comboBox_BaudRate.Size = new System.Drawing.Size(60, 20);
            this.comboBox_BaudRate.TabIndex = 1;
            this.comboBox_BaudRate.Text = "9600";
            // 
            // comboBox_Parity
            // 
            this.comboBox_Parity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Parity.FormattingEnabled = true;
            this.comboBox_Parity.Items.AddRange(new object[] {
            "NONE",
            "ODD",
            "EVEN"});
            this.comboBox_Parity.Location = new System.Drawing.Point(237, 21);
            this.comboBox_Parity.Name = "comboBox_Parity";
            this.comboBox_Parity.Size = new System.Drawing.Size(48, 20);
            this.comboBox_Parity.TabIndex = 1;
            this.comboBox_Parity.Text = "NONE";
            // 
            // labeltingzhiwei
            // 
            this.labeltingzhiwei.AutoSize = true;
            this.labeltingzhiwei.Location = new System.Drawing.Point(367, 25);
            this.labeltingzhiwei.Name = "labeltingzhiwei";
            this.labeltingzhiwei.Size = new System.Drawing.Size(41, 12);
            this.labeltingzhiwei.TabIndex = 0;
            this.labeltingzhiwei.Text = "停止位";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tableLayoutPanel3.ColumnCount = 12;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Controls.Add(this.checkBoxAllS, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.labelsdgggt, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.labelghj, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.labelasdffg, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.labesdasd, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.comboBox21, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.comboBox41, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.checkBox1, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label141, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.labeliuioui, 7, 0);
            this.tableLayoutPanel3.Controls.Add(this.labeliopiyu, 8, 0);
            this.tableLayoutPanel3.Controls.Add(this.labelvbcbg, 9, 0);
            this.tableLayoutPanel3.Controls.Add(this.labelgfhjgyu, 10, 0);
            this.tableLayoutPanel3.Controls.Add(this.label1, 5, 1);
            this.tableLayoutPanel3.Controls.Add(this.labeldfgdf, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.comboBox1, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.checkBox2, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.checkBox3, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.checkBox4, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.checkBox5, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.checkBox6, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.checkBox7, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.checkBox8, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.checkBox9, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.checkBox10, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.checkBox11, 1, 11);
            this.tableLayoutPanel3.Controls.Add(this.checkBox12, 1, 12);
            this.tableLayoutPanel3.Controls.Add(this.checkBox13, 1, 13);
            this.tableLayoutPanel3.Controls.Add(this.checkBox14, 1, 14);
            this.tableLayoutPanel3.Controls.Add(this.checkBox15, 1, 15);
            this.tableLayoutPanel3.Controls.Add(this.checkBox16, 1, 16);
            this.tableLayoutPanel3.Controls.Add(this.checkBox17, 1, 17);
            this.tableLayoutPanel3.Controls.Add(this.checkBox18, 1, 18);
            this.tableLayoutPanel3.Controls.Add(this.checkBox19, 1, 19);
            this.tableLayoutPanel3.Controls.Add(this.checkBox20, 1, 20);
            this.tableLayoutPanel3.Controls.Add(this.comboBox2, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.comboBox3, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.comboBox4, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.comboBox5, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.comboBox6, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.comboBox7, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.comboBox8, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.comboBox9, 2, 9);
            this.tableLayoutPanel3.Controls.Add(this.comboBox10, 2, 10);
            this.tableLayoutPanel3.Controls.Add(this.comboBox11, 2, 11);
            this.tableLayoutPanel3.Controls.Add(this.comboBox12, 2, 12);
            this.tableLayoutPanel3.Controls.Add(this.comboBox13, 2, 13);
            this.tableLayoutPanel3.Controls.Add(this.comboBox14, 2, 14);
            this.tableLayoutPanel3.Controls.Add(this.comboBox15, 2, 15);
            this.tableLayoutPanel3.Controls.Add(this.comboBox16, 2, 16);
            this.tableLayoutPanel3.Controls.Add(this.comboBox17, 2, 17);
            this.tableLayoutPanel3.Controls.Add(this.comboBox18, 2, 18);
            this.tableLayoutPanel3.Controls.Add(this.comboBox19, 2, 19);
            this.tableLayoutPanel3.Controls.Add(this.comboBox20, 2, 20);
            this.tableLayoutPanel3.Controls.Add(this.comboBox22, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.comboBox23, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.comboBox24, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.comboBox25, 3, 5);
            this.tableLayoutPanel3.Controls.Add(this.comboBox26, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.comboBox27, 3, 7);
            this.tableLayoutPanel3.Controls.Add(this.comboBox28, 3, 8);
            this.tableLayoutPanel3.Controls.Add(this.comboBox29, 3, 9);
            this.tableLayoutPanel3.Controls.Add(this.comboBox30, 3, 10);
            this.tableLayoutPanel3.Controls.Add(this.comboBox31, 3, 11);
            this.tableLayoutPanel3.Controls.Add(this.comboBox32, 3, 12);
            this.tableLayoutPanel3.Controls.Add(this.comboBox33, 3, 13);
            this.tableLayoutPanel3.Controls.Add(this.comboBox34, 3, 14);
            this.tableLayoutPanel3.Controls.Add(this.comboBox35, 3, 15);
            this.tableLayoutPanel3.Controls.Add(this.comboBox36, 3, 16);
            this.tableLayoutPanel3.Controls.Add(this.comboBox37, 3, 17);
            this.tableLayoutPanel3.Controls.Add(this.comboBox38, 3, 18);
            this.tableLayoutPanel3.Controls.Add(this.comboBox39, 3, 19);
            this.tableLayoutPanel3.Controls.Add(this.comboBox40, 3, 20);
            this.tableLayoutPanel3.Controls.Add(this.label2, 5, 2);
            this.tableLayoutPanel3.Controls.Add(this.label3, 5, 3);
            this.tableLayoutPanel3.Controls.Add(this.label4, 5, 4);
            this.tableLayoutPanel3.Controls.Add(this.label5, 5, 5);
            this.tableLayoutPanel3.Controls.Add(this.label6, 5, 6);
            this.tableLayoutPanel3.Controls.Add(this.label7, 5, 7);
            this.tableLayoutPanel3.Controls.Add(this.label8, 5, 8);
            this.tableLayoutPanel3.Controls.Add(this.label9, 5, 9);
            this.tableLayoutPanel3.Controls.Add(this.label10, 5, 10);
            this.tableLayoutPanel3.Controls.Add(this.label11, 5, 11);
            this.tableLayoutPanel3.Controls.Add(this.label12, 5, 12);
            this.tableLayoutPanel3.Controls.Add(this.label13, 5, 13);
            this.tableLayoutPanel3.Controls.Add(this.label14, 5, 14);
            this.tableLayoutPanel3.Controls.Add(this.label15, 5, 15);
            this.tableLayoutPanel3.Controls.Add(this.label16, 5, 16);
            this.tableLayoutPanel3.Controls.Add(this.label17, 5, 17);
            this.tableLayoutPanel3.Controls.Add(this.label18, 5, 18);
            this.tableLayoutPanel3.Controls.Add(this.label19, 5, 19);
            this.tableLayoutPanel3.Controls.Add(this.label20, 5, 20);
            this.tableLayoutPanel3.Controls.Add(this.label21, 6, 1);
            this.tableLayoutPanel3.Controls.Add(this.label22, 6, 2);
            this.tableLayoutPanel3.Controls.Add(this.label23, 6, 3);
            this.tableLayoutPanel3.Controls.Add(this.label24, 6, 4);
            this.tableLayoutPanel3.Controls.Add(this.label25, 6, 5);
            this.tableLayoutPanel3.Controls.Add(this.label26, 6, 6);
            this.tableLayoutPanel3.Controls.Add(this.label27, 6, 7);
            this.tableLayoutPanel3.Controls.Add(this.label28, 6, 8);
            this.tableLayoutPanel3.Controls.Add(this.label29, 6, 9);
            this.tableLayoutPanel3.Controls.Add(this.label30, 6, 10);
            this.tableLayoutPanel3.Controls.Add(this.label31, 6, 11);
            this.tableLayoutPanel3.Controls.Add(this.label32, 6, 12);
            this.tableLayoutPanel3.Controls.Add(this.label33, 6, 13);
            this.tableLayoutPanel3.Controls.Add(this.label34, 6, 14);
            this.tableLayoutPanel3.Controls.Add(this.label35, 6, 15);
            this.tableLayoutPanel3.Controls.Add(this.label36, 6, 16);
            this.tableLayoutPanel3.Controls.Add(this.label37, 6, 17);
            this.tableLayoutPanel3.Controls.Add(this.label38, 6, 18);
            this.tableLayoutPanel3.Controls.Add(this.label39, 6, 19);
            this.tableLayoutPanel3.Controls.Add(this.label40, 6, 20);
            this.tableLayoutPanel3.Controls.Add(this.label41, 7, 1);
            this.tableLayoutPanel3.Controls.Add(this.label42, 7, 2);
            this.tableLayoutPanel3.Controls.Add(this.label43, 7, 3);
            this.tableLayoutPanel3.Controls.Add(this.label44, 7, 4);
            this.tableLayoutPanel3.Controls.Add(this.label45, 7, 5);
            this.tableLayoutPanel3.Controls.Add(this.label46, 7, 6);
            this.tableLayoutPanel3.Controls.Add(this.label47, 7, 7);
            this.tableLayoutPanel3.Controls.Add(this.label48, 7, 8);
            this.tableLayoutPanel3.Controls.Add(this.label49, 7, 9);
            this.tableLayoutPanel3.Controls.Add(this.label50, 7, 10);
            this.tableLayoutPanel3.Controls.Add(this.label51, 7, 11);
            this.tableLayoutPanel3.Controls.Add(this.label52, 7, 12);
            this.tableLayoutPanel3.Controls.Add(this.label53, 7, 13);
            this.tableLayoutPanel3.Controls.Add(this.label54, 7, 14);
            this.tableLayoutPanel3.Controls.Add(this.label55, 7, 15);
            this.tableLayoutPanel3.Controls.Add(this.label56, 7, 16);
            this.tableLayoutPanel3.Controls.Add(this.label57, 7, 17);
            this.tableLayoutPanel3.Controls.Add(this.label58, 7, 18);
            this.tableLayoutPanel3.Controls.Add(this.label59, 7, 19);
            this.tableLayoutPanel3.Controls.Add(this.label60, 7, 20);
            this.tableLayoutPanel3.Controls.Add(this.label61, 8, 1);
            this.tableLayoutPanel3.Controls.Add(this.label62, 8, 2);
            this.tableLayoutPanel3.Controls.Add(this.label63, 8, 3);
            this.tableLayoutPanel3.Controls.Add(this.label64, 8, 4);
            this.tableLayoutPanel3.Controls.Add(this.label65, 8, 5);
            this.tableLayoutPanel3.Controls.Add(this.label66, 8, 6);
            this.tableLayoutPanel3.Controls.Add(this.label67, 8, 7);
            this.tableLayoutPanel3.Controls.Add(this.label68, 8, 8);
            this.tableLayoutPanel3.Controls.Add(this.label69, 8, 9);
            this.tableLayoutPanel3.Controls.Add(this.label70, 8, 10);
            this.tableLayoutPanel3.Controls.Add(this.label71, 8, 11);
            this.tableLayoutPanel3.Controls.Add(this.label72, 8, 12);
            this.tableLayoutPanel3.Controls.Add(this.label73, 8, 13);
            this.tableLayoutPanel3.Controls.Add(this.label74, 8, 14);
            this.tableLayoutPanel3.Controls.Add(this.label75, 8, 15);
            this.tableLayoutPanel3.Controls.Add(this.label76, 8, 16);
            this.tableLayoutPanel3.Controls.Add(this.label77, 8, 17);
            this.tableLayoutPanel3.Controls.Add(this.label78, 8, 18);
            this.tableLayoutPanel3.Controls.Add(this.label79, 8, 19);
            this.tableLayoutPanel3.Controls.Add(this.label80, 8, 20);
            this.tableLayoutPanel3.Controls.Add(this.label81, 9, 1);
            this.tableLayoutPanel3.Controls.Add(this.label82, 9, 2);
            this.tableLayoutPanel3.Controls.Add(this.label83, 9, 3);
            this.tableLayoutPanel3.Controls.Add(this.label84, 9, 4);
            this.tableLayoutPanel3.Controls.Add(this.label85, 9, 5);
            this.tableLayoutPanel3.Controls.Add(this.label86, 9, 6);
            this.tableLayoutPanel3.Controls.Add(this.label87, 9, 7);
            this.tableLayoutPanel3.Controls.Add(this.label88, 9, 8);
            this.tableLayoutPanel3.Controls.Add(this.label89, 9, 9);
            this.tableLayoutPanel3.Controls.Add(this.label90, 9, 10);
            this.tableLayoutPanel3.Controls.Add(this.label91, 9, 11);
            this.tableLayoutPanel3.Controls.Add(this.label92, 9, 12);
            this.tableLayoutPanel3.Controls.Add(this.label93, 9, 13);
            this.tableLayoutPanel3.Controls.Add(this.label94, 9, 14);
            this.tableLayoutPanel3.Controls.Add(this.label95, 9, 15);
            this.tableLayoutPanel3.Controls.Add(this.label96, 9, 16);
            this.tableLayoutPanel3.Controls.Add(this.label97, 9, 17);
            this.tableLayoutPanel3.Controls.Add(this.label98, 9, 18);
            this.tableLayoutPanel3.Controls.Add(this.label99, 9, 19);
            this.tableLayoutPanel3.Controls.Add(this.label100, 9, 20);
            this.tableLayoutPanel3.Controls.Add(this.label101, 10, 1);
            this.tableLayoutPanel3.Controls.Add(this.label102, 10, 2);
            this.tableLayoutPanel3.Controls.Add(this.label103, 10, 3);
            this.tableLayoutPanel3.Controls.Add(this.label104, 10, 4);
            this.tableLayoutPanel3.Controls.Add(this.label105, 10, 5);
            this.tableLayoutPanel3.Controls.Add(this.label106, 10, 6);
            this.tableLayoutPanel3.Controls.Add(this.label107, 10, 7);
            this.tableLayoutPanel3.Controls.Add(this.label108, 10, 8);
            this.tableLayoutPanel3.Controls.Add(this.label109, 10, 9);
            this.tableLayoutPanel3.Controls.Add(this.label110, 10, 10);
            this.tableLayoutPanel3.Controls.Add(this.label111, 10, 11);
            this.tableLayoutPanel3.Controls.Add(this.label112, 10, 12);
            this.tableLayoutPanel3.Controls.Add(this.label113, 10, 13);
            this.tableLayoutPanel3.Controls.Add(this.label114, 10, 14);
            this.tableLayoutPanel3.Controls.Add(this.label115, 10, 15);
            this.tableLayoutPanel3.Controls.Add(this.label116, 10, 16);
            this.tableLayoutPanel3.Controls.Add(this.label117, 10, 17);
            this.tableLayoutPanel3.Controls.Add(this.label118, 10, 18);
            this.tableLayoutPanel3.Controls.Add(this.label119, 10, 19);
            this.tableLayoutPanel3.Controls.Add(this.label120, 10, 20);
            this.tableLayoutPanel3.Controls.Add(this.label121, 11, 1);
            this.tableLayoutPanel3.Controls.Add(this.label122, 11, 2);
            this.tableLayoutPanel3.Controls.Add(this.label123, 11, 3);
            this.tableLayoutPanel3.Controls.Add(this.label124, 11, 4);
            this.tableLayoutPanel3.Controls.Add(this.label125, 11, 5);
            this.tableLayoutPanel3.Controls.Add(this.label126, 11, 6);
            this.tableLayoutPanel3.Controls.Add(this.label127, 11, 7);
            this.tableLayoutPanel3.Controls.Add(this.label128, 11, 8);
            this.tableLayoutPanel3.Controls.Add(this.label129, 11, 9);
            this.tableLayoutPanel3.Controls.Add(this.label130, 11, 10);
            this.tableLayoutPanel3.Controls.Add(this.label131, 11, 11);
            this.tableLayoutPanel3.Controls.Add(this.label132, 11, 12);
            this.tableLayoutPanel3.Controls.Add(this.label133, 11, 13);
            this.tableLayoutPanel3.Controls.Add(this.label134, 11, 14);
            this.tableLayoutPanel3.Controls.Add(this.label135, 11, 15);
            this.tableLayoutPanel3.Controls.Add(this.label136, 11, 16);
            this.tableLayoutPanel3.Controls.Add(this.label137, 11, 17);
            this.tableLayoutPanel3.Controls.Add(this.label138, 11, 18);
            this.tableLayoutPanel3.Controls.Add(this.label139, 11, 19);
            this.tableLayoutPanel3.Controls.Add(this.label140, 11, 20);
            this.tableLayoutPanel3.Controls.Add(this.label142, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label143, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label144, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label145, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label146, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label147, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label148, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.label149, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label150, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.label151, 0, 11);
            this.tableLayoutPanel3.Controls.Add(this.label152, 0, 12);
            this.tableLayoutPanel3.Controls.Add(this.label153, 0, 13);
            this.tableLayoutPanel3.Controls.Add(this.label154, 0, 14);
            this.tableLayoutPanel3.Controls.Add(this.label155, 0, 15);
            this.tableLayoutPanel3.Controls.Add(this.label156, 0, 16);
            this.tableLayoutPanel3.Controls.Add(this.label157, 0, 17);
            this.tableLayoutPanel3.Controls.Add(this.label158, 0, 18);
            this.tableLayoutPanel3.Controls.Add(this.label159, 0, 19);
            this.tableLayoutPanel3.Controls.Add(this.label160, 0, 20);
            this.tableLayoutPanel3.Controls.Add(this.comboBox42, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this.comboBox43, 4, 3);
            this.tableLayoutPanel3.Controls.Add(this.comboBox44, 4, 4);
            this.tableLayoutPanel3.Controls.Add(this.comboBox45, 4, 5);
            this.tableLayoutPanel3.Controls.Add(this.comboBox46, 4, 6);
            this.tableLayoutPanel3.Controls.Add(this.comboBox47, 4, 7);
            this.tableLayoutPanel3.Controls.Add(this.comboBox48, 4, 8);
            this.tableLayoutPanel3.Controls.Add(this.comboBox49, 4, 9);
            this.tableLayoutPanel3.Controls.Add(this.comboBox50, 4, 10);
            this.tableLayoutPanel3.Controls.Add(this.comboBox51, 4, 11);
            this.tableLayoutPanel3.Controls.Add(this.comboBox52, 4, 12);
            this.tableLayoutPanel3.Controls.Add(this.comboBox53, 4, 13);
            this.tableLayoutPanel3.Controls.Add(this.comboBox54, 4, 14);
            this.tableLayoutPanel3.Controls.Add(this.comboBox55, 4, 15);
            this.tableLayoutPanel3.Controls.Add(this.comboBox56, 4, 16);
            this.tableLayoutPanel3.Controls.Add(this.comboBox57, 4, 17);
            this.tableLayoutPanel3.Controls.Add(this.comboBox58, 4, 18);
            this.tableLayoutPanel3.Controls.Add(this.comboBox59, 4, 19);
            this.tableLayoutPanel3.Controls.Add(this.comboBox60, 4, 20);
            this.tableLayoutPanel3.Controls.Add(this.labelfghhhj, 12, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(12, 71);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 21;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.761906F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(700, 448);
            this.tableLayoutPanel3.TabIndex = 9;
            // 
            // checkBoxAllS
            // 
            this.checkBoxAllS.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBoxAllS.AutoSize = true;
            this.checkBoxAllS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBoxAllS.Location = new System.Drawing.Point(31, 5);
            this.checkBoxAllS.Name = "checkBoxAllS";
            this.checkBoxAllS.Size = new System.Drawing.Size(12, 11);
            this.checkBoxAllS.TabIndex = 4;
            this.checkBoxAllS.UseVisualStyleBackColor = true;
            this.checkBoxAllS.CheckedChanged += new System.EventHandler(this.CheckBoxAllS_CheckedChanged);
            // 
            // labelsdgggt
            // 
            this.labelsdgggt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelsdgggt.AutoSize = true;
            this.labelsdgggt.Location = new System.Drawing.Point(251, 4);
            this.labelsdgggt.Name = "labelsdgggt";
            this.labelsdgggt.Size = new System.Drawing.Size(53, 12);
            this.labelsdgggt.TabIndex = 0;
            this.labelsdgggt.Text = "温度(℃)";
            // 
            // labelghj
            // 
            this.labelghj.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelghj.AutoSize = true;
            this.labelghj.Location = new System.Drawing.Point(319, 4);
            this.labelghj.Name = "labelghj";
            this.labelghj.Size = new System.Drawing.Size(47, 12);
            this.labelghj.TabIndex = 0;
            this.labelghj.Text = "电压(v)";
            // 
            // labelasdffg
            // 
            this.labelasdffg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelasdffg.AutoSize = true;
            this.labelasdffg.Location = new System.Drawing.Point(189, 4);
            this.labelasdffg.Name = "labelasdffg";
            this.labelasdffg.Size = new System.Drawing.Size(47, 12);
            this.labelasdffg.TabIndex = 0;
            this.labelasdffg.Text = "电流(A)";
            // 
            // labesdasd
            // 
            this.labesdasd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labesdasd.AutoSize = true;
            this.labesdasd.Location = new System.Drawing.Point(124, 4);
            this.labesdasd.Name = "labesdasd";
            this.labesdasd.Size = new System.Drawing.Size(47, 12);
            this.labesdasd.TabIndex = 0;
            this.labesdasd.Text = "电压(V)";
            // 
            // comboBox21
            // 
            this.comboBox21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox21.FormattingEnabled = true;
            this.comboBox21.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox21.Location = new System.Drawing.Point(124, 24);
            this.comboBox21.Name = "comboBox21";
            this.comboBox21.Size = new System.Drawing.Size(47, 20);
            this.comboBox21.TabIndex = 1;
            this.comboBox21.Text = "5";
            // 
            // comboBox41
            // 
            this.comboBox41.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox41.FormattingEnabled = true;
            this.comboBox41.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox41.Location = new System.Drawing.Point(189, 24);
            this.comboBox41.Name = "comboBox41";
            this.comboBox41.Size = new System.Drawing.Size(47, 20);
            this.comboBox41.TabIndex = 1;
            this.comboBox41.Text = "1";
            // 
            // checkBox1
            // 
            this.checkBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox1.AutoSize = true;
            this.checkBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox1.Location = new System.Drawing.Point(31, 26);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(12, 11);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label141
            // 
            this.label141.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(4, 25);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(17, 12);
            this.label141.TabIndex = 0;
            this.label141.Text = "01";
            // 
            // labeliuioui
            // 
            this.labeliuioui.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labeliuioui.AutoSize = true;
            this.labeliuioui.Location = new System.Drawing.Point(384, 4);
            this.labeliuioui.Name = "labeliuioui";
            this.labeliuioui.Size = new System.Drawing.Size(47, 12);
            this.labeliuioui.TabIndex = 0;
            this.labeliuioui.Text = "电流(A)";
            // 
            // labeliopiyu
            // 
            this.labeliopiyu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labeliopiyu.AutoSize = true;
            this.labeliopiyu.Location = new System.Drawing.Point(449, 4);
            this.labeliopiyu.Name = "labeliopiyu";
            this.labeliopiyu.Size = new System.Drawing.Size(47, 12);
            this.labeliopiyu.TabIndex = 0;
            this.labeliopiyu.Text = "功率(W)";
            // 
            // labelvbcbg
            // 
            this.labelvbcbg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelvbcbg.AutoSize = true;
            this.labelvbcbg.Location = new System.Drawing.Point(511, 4);
            this.labelvbcbg.Name = "labelvbcbg";
            this.labelvbcbg.Size = new System.Drawing.Size(53, 12);
            this.labelvbcbg.TabIndex = 0;
            this.labelvbcbg.Text = "容量(Ah)";
            // 
            // labelgfhjgyu
            // 
            this.labelgfhjgyu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelgfhjgyu.AutoSize = true;
            this.labelgfhjgyu.Location = new System.Drawing.Point(573, 4);
            this.labelgfhjgyu.Name = "labelgfhjgyu";
            this.labelgfhjgyu.Size = new System.Drawing.Size(59, 12);
            this.labelgfhjgyu.TabIndex = 0;
            this.labelgfhjgyu.Text = "瓦时(mAh)";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(263, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "0000";
            // 
            // labeldfgdf
            // 
            this.labeldfgdf.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labeldfgdf.AutoSize = true;
            this.labeldfgdf.Location = new System.Drawing.Point(68, 4);
            this.labeldfgdf.Name = "labeldfgdf";
            this.labeldfgdf.Size = new System.Drawing.Size(29, 12);
            this.labeldfgdf.TabIndex = 0;
            this.labeldfgdf.Text = "模式";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox1.Location = new System.Drawing.Point(59, 24);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(47, 20);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.Text = "CC";
            // 
            // checkBox2
            // 
            this.checkBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox2.AutoSize = true;
            this.checkBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox2.Location = new System.Drawing.Point(31, 47);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(12, 11);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox3.AutoSize = true;
            this.checkBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox3.Location = new System.Drawing.Point(31, 68);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(12, 11);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox4.AutoSize = true;
            this.checkBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox4.Location = new System.Drawing.Point(31, 89);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(12, 11);
            this.checkBox4.TabIndex = 4;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox5.AutoSize = true;
            this.checkBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox5.Location = new System.Drawing.Point(31, 110);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(12, 11);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox6.AutoSize = true;
            this.checkBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox6.Location = new System.Drawing.Point(31, 131);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(12, 11);
            this.checkBox6.TabIndex = 4;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox7.AutoSize = true;
            this.checkBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox7.Location = new System.Drawing.Point(31, 152);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(12, 11);
            this.checkBox7.TabIndex = 4;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox8.AutoSize = true;
            this.checkBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox8.Location = new System.Drawing.Point(31, 173);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(12, 11);
            this.checkBox8.TabIndex = 4;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox9.AutoSize = true;
            this.checkBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox9.Location = new System.Drawing.Point(31, 194);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(12, 11);
            this.checkBox9.TabIndex = 4;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox10.AutoSize = true;
            this.checkBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox10.Location = new System.Drawing.Point(31, 215);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(12, 11);
            this.checkBox10.TabIndex = 4;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox11.AutoSize = true;
            this.checkBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox11.Location = new System.Drawing.Point(31, 236);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(12, 11);
            this.checkBox11.TabIndex = 4;
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox12.AutoSize = true;
            this.checkBox12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox12.Location = new System.Drawing.Point(31, 257);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(12, 11);
            this.checkBox12.TabIndex = 4;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox13.AutoSize = true;
            this.checkBox13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox13.Location = new System.Drawing.Point(31, 278);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(12, 11);
            this.checkBox13.TabIndex = 4;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox14.AutoSize = true;
            this.checkBox14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox14.Location = new System.Drawing.Point(31, 299);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(12, 11);
            this.checkBox14.TabIndex = 4;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox15.AutoSize = true;
            this.checkBox15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox15.Location = new System.Drawing.Point(31, 320);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(12, 11);
            this.checkBox15.TabIndex = 4;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox16.AutoSize = true;
            this.checkBox16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox16.Location = new System.Drawing.Point(31, 341);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(12, 11);
            this.checkBox16.TabIndex = 4;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox17.AutoSize = true;
            this.checkBox17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox17.Location = new System.Drawing.Point(31, 362);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(12, 11);
            this.checkBox17.TabIndex = 4;
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox18.AutoSize = true;
            this.checkBox18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox18.Location = new System.Drawing.Point(31, 383);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(12, 11);
            this.checkBox18.TabIndex = 4;
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox19.AutoSize = true;
            this.checkBox19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox19.Location = new System.Drawing.Point(31, 404);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(12, 11);
            this.checkBox19.TabIndex = 4;
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBox20.AutoSize = true;
            this.checkBox20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox20.Location = new System.Drawing.Point(31, 428);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(12, 11);
            this.checkBox20.TabIndex = 4;
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox2.Location = new System.Drawing.Point(59, 45);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(47, 20);
            this.comboBox2.TabIndex = 1;
            this.comboBox2.Text = "CC";
            // 
            // comboBox3
            // 
            this.comboBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox3.Location = new System.Drawing.Point(59, 66);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(47, 20);
            this.comboBox3.TabIndex = 1;
            this.comboBox3.Text = "CC";
            // 
            // comboBox4
            // 
            this.comboBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox4.Location = new System.Drawing.Point(59, 87);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(47, 20);
            this.comboBox4.TabIndex = 1;
            this.comboBox4.Text = "CC";
            // 
            // comboBox5
            // 
            this.comboBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox5.Location = new System.Drawing.Point(59, 108);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(47, 20);
            this.comboBox5.TabIndex = 1;
            this.comboBox5.Text = "CC";
            // 
            // comboBox6
            // 
            this.comboBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox6.Location = new System.Drawing.Point(59, 129);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(47, 20);
            this.comboBox6.TabIndex = 1;
            this.comboBox6.Text = "CC";
            // 
            // comboBox7
            // 
            this.comboBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox7.Location = new System.Drawing.Point(59, 150);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(47, 20);
            this.comboBox7.TabIndex = 1;
            this.comboBox7.Text = "CC";
            // 
            // comboBox8
            // 
            this.comboBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox8.Location = new System.Drawing.Point(59, 171);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(47, 20);
            this.comboBox8.TabIndex = 1;
            this.comboBox8.Text = "CC";
            // 
            // comboBox9
            // 
            this.comboBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox9.Location = new System.Drawing.Point(59, 192);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(47, 20);
            this.comboBox9.TabIndex = 1;
            this.comboBox9.Text = "CC";
            // 
            // comboBox10
            // 
            this.comboBox10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox10.Location = new System.Drawing.Point(59, 213);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(47, 20);
            this.comboBox10.TabIndex = 1;
            this.comboBox10.Text = "CC";
            // 
            // comboBox11
            // 
            this.comboBox11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox11.Location = new System.Drawing.Point(59, 234);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(47, 20);
            this.comboBox11.TabIndex = 1;
            this.comboBox11.Text = "CC";
            // 
            // comboBox12
            // 
            this.comboBox12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox12.Location = new System.Drawing.Point(59, 255);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(47, 20);
            this.comboBox12.TabIndex = 1;
            this.comboBox12.Text = "CC";
            // 
            // comboBox13
            // 
            this.comboBox13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox13.Location = new System.Drawing.Point(59, 276);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(47, 20);
            this.comboBox13.TabIndex = 1;
            this.comboBox13.Text = "CC";
            // 
            // comboBox14
            // 
            this.comboBox14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox14.Location = new System.Drawing.Point(59, 297);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(47, 20);
            this.comboBox14.TabIndex = 1;
            this.comboBox14.Text = "CC";
            // 
            // comboBox15
            // 
            this.comboBox15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox15.Location = new System.Drawing.Point(59, 318);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(47, 20);
            this.comboBox15.TabIndex = 1;
            this.comboBox15.Text = "CC";
            // 
            // comboBox16
            // 
            this.comboBox16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox16.Location = new System.Drawing.Point(59, 339);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(47, 20);
            this.comboBox16.TabIndex = 1;
            this.comboBox16.Text = "CC";
            // 
            // comboBox17
            // 
            this.comboBox17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox17.Location = new System.Drawing.Point(59, 360);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(47, 20);
            this.comboBox17.TabIndex = 1;
            this.comboBox17.Text = "CC";
            // 
            // comboBox18
            // 
            this.comboBox18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox18.Location = new System.Drawing.Point(59, 381);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(47, 20);
            this.comboBox18.TabIndex = 1;
            this.comboBox18.Text = "CC";
            // 
            // comboBox19
            // 
            this.comboBox19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox19.Location = new System.Drawing.Point(59, 402);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(47, 20);
            this.comboBox19.TabIndex = 1;
            this.comboBox19.Text = "CC";
            // 
            // comboBox20
            // 
            this.comboBox20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.Items.AddRange(new object[] {
            "CV",
            "CC",
            "CW",
            "CR"});
            this.comboBox20.Location = new System.Drawing.Point(59, 424);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(47, 20);
            this.comboBox20.TabIndex = 1;
            this.comboBox20.Text = "CC";
            // 
            // comboBox22
            // 
            this.comboBox22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox22.FormattingEnabled = true;
            this.comboBox22.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox22.Location = new System.Drawing.Point(124, 45);
            this.comboBox22.Name = "comboBox22";
            this.comboBox22.Size = new System.Drawing.Size(47, 20);
            this.comboBox22.TabIndex = 1;
            this.comboBox22.Text = "5";
            // 
            // comboBox23
            // 
            this.comboBox23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox23.FormattingEnabled = true;
            this.comboBox23.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox23.Location = new System.Drawing.Point(124, 66);
            this.comboBox23.Name = "comboBox23";
            this.comboBox23.Size = new System.Drawing.Size(47, 20);
            this.comboBox23.TabIndex = 1;
            this.comboBox23.Text = "5";
            // 
            // comboBox24
            // 
            this.comboBox24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox24.Location = new System.Drawing.Point(124, 87);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(47, 20);
            this.comboBox24.TabIndex = 1;
            this.comboBox24.Text = "5";
            // 
            // comboBox25
            // 
            this.comboBox25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox25.Location = new System.Drawing.Point(124, 108);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(47, 20);
            this.comboBox25.TabIndex = 1;
            this.comboBox25.Text = "5";
            // 
            // comboBox26
            // 
            this.comboBox26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox26.FormattingEnabled = true;
            this.comboBox26.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox26.Location = new System.Drawing.Point(124, 129);
            this.comboBox26.Name = "comboBox26";
            this.comboBox26.Size = new System.Drawing.Size(47, 20);
            this.comboBox26.TabIndex = 1;
            this.comboBox26.Text = "5";
            // 
            // comboBox27
            // 
            this.comboBox27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox27.FormattingEnabled = true;
            this.comboBox27.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox27.Location = new System.Drawing.Point(124, 150);
            this.comboBox27.Name = "comboBox27";
            this.comboBox27.Size = new System.Drawing.Size(47, 20);
            this.comboBox27.TabIndex = 1;
            this.comboBox27.Text = "5";
            // 
            // comboBox28
            // 
            this.comboBox28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox28.FormattingEnabled = true;
            this.comboBox28.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox28.Location = new System.Drawing.Point(124, 171);
            this.comboBox28.Name = "comboBox28";
            this.comboBox28.Size = new System.Drawing.Size(47, 20);
            this.comboBox28.TabIndex = 1;
            this.comboBox28.Text = "5";
            // 
            // comboBox29
            // 
            this.comboBox29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox29.FormattingEnabled = true;
            this.comboBox29.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox29.Location = new System.Drawing.Point(124, 192);
            this.comboBox29.Name = "comboBox29";
            this.comboBox29.Size = new System.Drawing.Size(47, 20);
            this.comboBox29.TabIndex = 1;
            this.comboBox29.Text = "5";
            // 
            // comboBox30
            // 
            this.comboBox30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox30.FormattingEnabled = true;
            this.comboBox30.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox30.Location = new System.Drawing.Point(124, 213);
            this.comboBox30.Name = "comboBox30";
            this.comboBox30.Size = new System.Drawing.Size(47, 20);
            this.comboBox30.TabIndex = 1;
            this.comboBox30.Text = "5";
            // 
            // comboBox31
            // 
            this.comboBox31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox31.FormattingEnabled = true;
            this.comboBox31.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox31.Location = new System.Drawing.Point(124, 234);
            this.comboBox31.Name = "comboBox31";
            this.comboBox31.Size = new System.Drawing.Size(47, 20);
            this.comboBox31.TabIndex = 1;
            this.comboBox31.Text = "5";
            // 
            // comboBox32
            // 
            this.comboBox32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox32.FormattingEnabled = true;
            this.comboBox32.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox32.Location = new System.Drawing.Point(124, 255);
            this.comboBox32.Name = "comboBox32";
            this.comboBox32.Size = new System.Drawing.Size(47, 20);
            this.comboBox32.TabIndex = 1;
            this.comboBox32.Text = "5";
            // 
            // comboBox33
            // 
            this.comboBox33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox33.FormattingEnabled = true;
            this.comboBox33.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox33.Location = new System.Drawing.Point(124, 276);
            this.comboBox33.Name = "comboBox33";
            this.comboBox33.Size = new System.Drawing.Size(47, 20);
            this.comboBox33.TabIndex = 1;
            this.comboBox33.Text = "5";
            // 
            // comboBox34
            // 
            this.comboBox34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox34.FormattingEnabled = true;
            this.comboBox34.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox34.Location = new System.Drawing.Point(124, 297);
            this.comboBox34.Name = "comboBox34";
            this.comboBox34.Size = new System.Drawing.Size(47, 20);
            this.comboBox34.TabIndex = 1;
            this.comboBox34.Text = "5";
            // 
            // comboBox35
            // 
            this.comboBox35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox35.FormattingEnabled = true;
            this.comboBox35.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox35.Location = new System.Drawing.Point(124, 318);
            this.comboBox35.Name = "comboBox35";
            this.comboBox35.Size = new System.Drawing.Size(47, 20);
            this.comboBox35.TabIndex = 1;
            this.comboBox35.Text = "5";
            // 
            // comboBox36
            // 
            this.comboBox36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox36.FormattingEnabled = true;
            this.comboBox36.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox36.Location = new System.Drawing.Point(124, 339);
            this.comboBox36.Name = "comboBox36";
            this.comboBox36.Size = new System.Drawing.Size(47, 20);
            this.comboBox36.TabIndex = 1;
            this.comboBox36.Text = "5";
            // 
            // comboBox37
            // 
            this.comboBox37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox37.FormattingEnabled = true;
            this.comboBox37.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox37.Location = new System.Drawing.Point(124, 360);
            this.comboBox37.Name = "comboBox37";
            this.comboBox37.Size = new System.Drawing.Size(47, 20);
            this.comboBox37.TabIndex = 1;
            this.comboBox37.Text = "5";
            // 
            // comboBox38
            // 
            this.comboBox38.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox38.FormattingEnabled = true;
            this.comboBox38.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox38.Location = new System.Drawing.Point(124, 381);
            this.comboBox38.Name = "comboBox38";
            this.comboBox38.Size = new System.Drawing.Size(47, 20);
            this.comboBox38.TabIndex = 1;
            this.comboBox38.Text = "5";
            // 
            // comboBox39
            // 
            this.comboBox39.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox39.FormattingEnabled = true;
            this.comboBox39.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox39.Location = new System.Drawing.Point(124, 402);
            this.comboBox39.Name = "comboBox39";
            this.comboBox39.Size = new System.Drawing.Size(47, 20);
            this.comboBox39.TabIndex = 1;
            this.comboBox39.Text = "5";
            // 
            // comboBox40
            // 
            this.comboBox40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox40.FormattingEnabled = true;
            this.comboBox40.Items.AddRange(new object[] {
            "5",
            "2.5"});
            this.comboBox40.Location = new System.Drawing.Point(124, 424);
            this.comboBox40.Name = "comboBox40";
            this.comboBox40.Size = new System.Drawing.Size(47, 20);
            this.comboBox40.TabIndex = 1;
            this.comboBox40.Text = "5";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(263, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "0000";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(263, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "0000";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(263, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "0000";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(263, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "0000";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(263, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "0000";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(263, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "0000";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(263, 172);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "0000";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(263, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "0000";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(263, 214);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "0000";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(263, 235);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "0000";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(263, 256);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "0000";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(263, 277);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "0000";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(263, 298);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "0000";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(263, 319);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "0000";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(263, 340);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "0000";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(263, 361);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "0000";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(263, 382);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "0000";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(263, 403);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "0000";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(263, 428);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "0000";
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(328, 25);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 12);
            this.label21.TabIndex = 0;
            this.label21.Text = "0000";
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(328, 46);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "0000";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(328, 67);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 12);
            this.label23.TabIndex = 0;
            this.label23.Text = "0000";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(328, 88);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 0;
            this.label24.Text = "0000";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(328, 109);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "0000";
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(328, 130);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "0000";
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(328, 151);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 12);
            this.label27.TabIndex = 0;
            this.label27.Text = "0000";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(328, 172);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 12);
            this.label28.TabIndex = 0;
            this.label28.Text = "0000";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(328, 193);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "0000";
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(328, 214);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 12);
            this.label30.TabIndex = 0;
            this.label30.Text = "0000";
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(328, 235);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "0000";
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(328, 256);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 12);
            this.label32.TabIndex = 0;
            this.label32.Text = "0000";
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(328, 277);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(29, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "0000";
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(328, 298);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 12);
            this.label34.TabIndex = 0;
            this.label34.Text = "0000";
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(328, 319);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(29, 12);
            this.label35.TabIndex = 0;
            this.label35.Text = "0000";
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(328, 340);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 12);
            this.label36.TabIndex = 0;
            this.label36.Text = "0000";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(328, 361);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(29, 12);
            this.label37.TabIndex = 0;
            this.label37.Text = "0000";
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(328, 382);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 12);
            this.label38.TabIndex = 0;
            this.label38.Text = "0000";
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(328, 403);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 12);
            this.label39.TabIndex = 0;
            this.label39.Text = "0000";
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(328, 428);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(29, 12);
            this.label40.TabIndex = 0;
            this.label40.Text = "0000";
            // 
            // label41
            // 
            this.label41.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(393, 25);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(29, 12);
            this.label41.TabIndex = 0;
            this.label41.Text = "0000";
            // 
            // label42
            // 
            this.label42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(393, 46);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(29, 12);
            this.label42.TabIndex = 0;
            this.label42.Text = "0000";
            // 
            // label43
            // 
            this.label43.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(393, 67);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(29, 12);
            this.label43.TabIndex = 0;
            this.label43.Text = "0000";
            // 
            // label44
            // 
            this.label44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(393, 88);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(29, 12);
            this.label44.TabIndex = 0;
            this.label44.Text = "0000";
            // 
            // label45
            // 
            this.label45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(393, 109);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(29, 12);
            this.label45.TabIndex = 0;
            this.label45.Text = "0000";
            // 
            // label46
            // 
            this.label46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(393, 130);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(29, 12);
            this.label46.TabIndex = 0;
            this.label46.Text = "0000";
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(393, 151);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(29, 12);
            this.label47.TabIndex = 0;
            this.label47.Text = "0000";
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(393, 172);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(29, 12);
            this.label48.TabIndex = 0;
            this.label48.Text = "0000";
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(393, 193);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(29, 12);
            this.label49.TabIndex = 0;
            this.label49.Text = "0000";
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(393, 214);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(29, 12);
            this.label50.TabIndex = 0;
            this.label50.Text = "0000";
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(393, 235);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(29, 12);
            this.label51.TabIndex = 0;
            this.label51.Text = "0000";
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(393, 256);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(29, 12);
            this.label52.TabIndex = 0;
            this.label52.Text = "0000";
            // 
            // label53
            // 
            this.label53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(393, 277);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(29, 12);
            this.label53.TabIndex = 0;
            this.label53.Text = "0000";
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(393, 298);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(29, 12);
            this.label54.TabIndex = 0;
            this.label54.Text = "0000";
            // 
            // label55
            // 
            this.label55.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(393, 319);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(29, 12);
            this.label55.TabIndex = 0;
            this.label55.Text = "0000";
            // 
            // label56
            // 
            this.label56.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(393, 340);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(29, 12);
            this.label56.TabIndex = 0;
            this.label56.Text = "0000";
            // 
            // label57
            // 
            this.label57.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(393, 361);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(29, 12);
            this.label57.TabIndex = 0;
            this.label57.Text = "0000";
            // 
            // label58
            // 
            this.label58.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(393, 382);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(29, 12);
            this.label58.TabIndex = 0;
            this.label58.Text = "0000";
            // 
            // label59
            // 
            this.label59.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(393, 403);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(29, 12);
            this.label59.TabIndex = 0;
            this.label59.Text = "0000";
            // 
            // label60
            // 
            this.label60.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(393, 428);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(29, 12);
            this.label60.TabIndex = 0;
            this.label60.Text = "0000";
            // 
            // label61
            // 
            this.label61.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(458, 25);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(29, 12);
            this.label61.TabIndex = 0;
            this.label61.Text = "0000";
            // 
            // label62
            // 
            this.label62.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(458, 46);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(29, 12);
            this.label62.TabIndex = 0;
            this.label62.Text = "0000";
            // 
            // label63
            // 
            this.label63.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(458, 67);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(29, 12);
            this.label63.TabIndex = 0;
            this.label63.Text = "0000";
            // 
            // label64
            // 
            this.label64.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(458, 88);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(29, 12);
            this.label64.TabIndex = 0;
            this.label64.Text = "0000";
            // 
            // label65
            // 
            this.label65.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(458, 109);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(29, 12);
            this.label65.TabIndex = 0;
            this.label65.Text = "0000";
            // 
            // label66
            // 
            this.label66.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(458, 130);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(29, 12);
            this.label66.TabIndex = 0;
            this.label66.Text = "0000";
            // 
            // label67
            // 
            this.label67.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(458, 151);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(29, 12);
            this.label67.TabIndex = 0;
            this.label67.Text = "0000";
            // 
            // label68
            // 
            this.label68.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(458, 172);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(29, 12);
            this.label68.TabIndex = 0;
            this.label68.Text = "0000";
            // 
            // label69
            // 
            this.label69.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(458, 193);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(29, 12);
            this.label69.TabIndex = 0;
            this.label69.Text = "0000";
            // 
            // label70
            // 
            this.label70.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(458, 214);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(29, 12);
            this.label70.TabIndex = 0;
            this.label70.Text = "0000";
            // 
            // label71
            // 
            this.label71.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(458, 235);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(29, 12);
            this.label71.TabIndex = 0;
            this.label71.Text = "0000";
            // 
            // label72
            // 
            this.label72.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(458, 256);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(29, 12);
            this.label72.TabIndex = 0;
            this.label72.Text = "0000";
            // 
            // label73
            // 
            this.label73.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(458, 277);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(29, 12);
            this.label73.TabIndex = 0;
            this.label73.Text = "0000";
            // 
            // label74
            // 
            this.label74.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(458, 298);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(29, 12);
            this.label74.TabIndex = 0;
            this.label74.Text = "0000";
            // 
            // label75
            // 
            this.label75.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(458, 319);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(29, 12);
            this.label75.TabIndex = 0;
            this.label75.Text = "0000";
            // 
            // label76
            // 
            this.label76.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(458, 340);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(29, 12);
            this.label76.TabIndex = 0;
            this.label76.Text = "0000";
            // 
            // label77
            // 
            this.label77.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(458, 361);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(29, 12);
            this.label77.TabIndex = 0;
            this.label77.Text = "0000";
            // 
            // label78
            // 
            this.label78.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(458, 382);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(29, 12);
            this.label78.TabIndex = 0;
            this.label78.Text = "0000";
            // 
            // label79
            // 
            this.label79.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(458, 403);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(29, 12);
            this.label79.TabIndex = 0;
            this.label79.Text = "0000";
            // 
            // label80
            // 
            this.label80.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(458, 428);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(29, 12);
            this.label80.TabIndex = 0;
            this.label80.Text = "0000";
            // 
            // label81
            // 
            this.label81.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(523, 25);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(29, 12);
            this.label81.TabIndex = 0;
            this.label81.Text = "0000";
            // 
            // label82
            // 
            this.label82.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(523, 46);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(29, 12);
            this.label82.TabIndex = 0;
            this.label82.Text = "0000";
            // 
            // label83
            // 
            this.label83.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(523, 67);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(29, 12);
            this.label83.TabIndex = 0;
            this.label83.Text = "0000";
            // 
            // label84
            // 
            this.label84.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(523, 88);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(29, 12);
            this.label84.TabIndex = 0;
            this.label84.Text = "0000";
            // 
            // label85
            // 
            this.label85.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(523, 109);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(29, 12);
            this.label85.TabIndex = 0;
            this.label85.Text = "0000";
            // 
            // label86
            // 
            this.label86.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(523, 130);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(29, 12);
            this.label86.TabIndex = 0;
            this.label86.Text = "0000";
            // 
            // label87
            // 
            this.label87.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(523, 151);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(29, 12);
            this.label87.TabIndex = 0;
            this.label87.Text = "0000";
            // 
            // label88
            // 
            this.label88.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(523, 172);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(29, 12);
            this.label88.TabIndex = 0;
            this.label88.Text = "0000";
            // 
            // label89
            // 
            this.label89.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(523, 193);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(29, 12);
            this.label89.TabIndex = 0;
            this.label89.Text = "0000";
            // 
            // label90
            // 
            this.label90.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(523, 214);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(29, 12);
            this.label90.TabIndex = 0;
            this.label90.Text = "0000";
            // 
            // label91
            // 
            this.label91.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(523, 235);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(29, 12);
            this.label91.TabIndex = 0;
            this.label91.Text = "0000";
            // 
            // label92
            // 
            this.label92.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(523, 256);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(29, 12);
            this.label92.TabIndex = 0;
            this.label92.Text = "0000";
            // 
            // label93
            // 
            this.label93.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(523, 277);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(29, 12);
            this.label93.TabIndex = 0;
            this.label93.Text = "0000";
            // 
            // label94
            // 
            this.label94.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(523, 298);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(29, 12);
            this.label94.TabIndex = 0;
            this.label94.Text = "0000";
            // 
            // label95
            // 
            this.label95.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(523, 319);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(29, 12);
            this.label95.TabIndex = 0;
            this.label95.Text = "0000";
            // 
            // label96
            // 
            this.label96.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(523, 340);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(29, 12);
            this.label96.TabIndex = 0;
            this.label96.Text = "0000";
            // 
            // label97
            // 
            this.label97.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(523, 361);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(29, 12);
            this.label97.TabIndex = 0;
            this.label97.Text = "0000";
            // 
            // label98
            // 
            this.label98.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(523, 382);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(29, 12);
            this.label98.TabIndex = 0;
            this.label98.Text = "0000";
            // 
            // label99
            // 
            this.label99.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(523, 403);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(29, 12);
            this.label99.TabIndex = 0;
            this.label99.Text = "0000";
            // 
            // label100
            // 
            this.label100.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(523, 428);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(29, 12);
            this.label100.TabIndex = 0;
            this.label100.Text = "0000";
            // 
            // label101
            // 
            this.label101.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(588, 25);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(29, 12);
            this.label101.TabIndex = 0;
            this.label101.Text = "0000";
            // 
            // label102
            // 
            this.label102.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(588, 46);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(29, 12);
            this.label102.TabIndex = 0;
            this.label102.Text = "0000";
            // 
            // label103
            // 
            this.label103.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(588, 67);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(29, 12);
            this.label103.TabIndex = 0;
            this.label103.Text = "0000";
            // 
            // label104
            // 
            this.label104.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(588, 88);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(29, 12);
            this.label104.TabIndex = 0;
            this.label104.Text = "0000";
            // 
            // label105
            // 
            this.label105.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(588, 109);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(29, 12);
            this.label105.TabIndex = 0;
            this.label105.Text = "0000";
            // 
            // label106
            // 
            this.label106.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(588, 130);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(29, 12);
            this.label106.TabIndex = 0;
            this.label106.Text = "0000";
            // 
            // label107
            // 
            this.label107.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(588, 151);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(29, 12);
            this.label107.TabIndex = 0;
            this.label107.Text = "0000";
            // 
            // label108
            // 
            this.label108.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(588, 172);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(29, 12);
            this.label108.TabIndex = 0;
            this.label108.Text = "0000";
            // 
            // label109
            // 
            this.label109.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(588, 193);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(29, 12);
            this.label109.TabIndex = 0;
            this.label109.Text = "0000";
            // 
            // label110
            // 
            this.label110.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(588, 214);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(29, 12);
            this.label110.TabIndex = 0;
            this.label110.Text = "0000";
            // 
            // label111
            // 
            this.label111.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(588, 235);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(29, 12);
            this.label111.TabIndex = 0;
            this.label111.Text = "0000";
            // 
            // label112
            // 
            this.label112.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(588, 256);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(29, 12);
            this.label112.TabIndex = 0;
            this.label112.Text = "0000";
            // 
            // label113
            // 
            this.label113.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(588, 277);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(29, 12);
            this.label113.TabIndex = 0;
            this.label113.Text = "0000";
            // 
            // label114
            // 
            this.label114.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(588, 298);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(29, 12);
            this.label114.TabIndex = 0;
            this.label114.Text = "0000";
            // 
            // label115
            // 
            this.label115.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(588, 319);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(29, 12);
            this.label115.TabIndex = 0;
            this.label115.Text = "0000";
            // 
            // label116
            // 
            this.label116.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(588, 340);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(29, 12);
            this.label116.TabIndex = 0;
            this.label116.Text = "0000";
            // 
            // label117
            // 
            this.label117.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(588, 361);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(29, 12);
            this.label117.TabIndex = 0;
            this.label117.Text = "0000";
            // 
            // label118
            // 
            this.label118.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(588, 382);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(29, 12);
            this.label118.TabIndex = 0;
            this.label118.Text = "0000";
            // 
            // label119
            // 
            this.label119.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(588, 403);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(29, 12);
            this.label119.TabIndex = 0;
            this.label119.Text = "0000";
            // 
            // label120
            // 
            this.label120.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(588, 428);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(29, 12);
            this.label120.TabIndex = 0;
            this.label120.Text = "0000";
            // 
            // label121
            // 
            this.label121.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(653, 25);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(29, 12);
            this.label121.TabIndex = 0;
            this.label121.Text = "0000";
            // 
            // label122
            // 
            this.label122.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(653, 46);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(29, 12);
            this.label122.TabIndex = 0;
            this.label122.Text = "0000";
            // 
            // label123
            // 
            this.label123.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(653, 67);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(29, 12);
            this.label123.TabIndex = 0;
            this.label123.Text = "0000";
            // 
            // label124
            // 
            this.label124.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(653, 88);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(29, 12);
            this.label124.TabIndex = 0;
            this.label124.Text = "0000";
            // 
            // label125
            // 
            this.label125.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(653, 109);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(29, 12);
            this.label125.TabIndex = 0;
            this.label125.Text = "0000";
            // 
            // label126
            // 
            this.label126.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(653, 130);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(29, 12);
            this.label126.TabIndex = 0;
            this.label126.Text = "0000";
            // 
            // label127
            // 
            this.label127.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(653, 151);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(29, 12);
            this.label127.TabIndex = 0;
            this.label127.Text = "0000";
            // 
            // label128
            // 
            this.label128.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(653, 172);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(29, 12);
            this.label128.TabIndex = 0;
            this.label128.Text = "0000";
            // 
            // label129
            // 
            this.label129.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(653, 193);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(29, 12);
            this.label129.TabIndex = 0;
            this.label129.Text = "0000";
            // 
            // label130
            // 
            this.label130.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(653, 214);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(29, 12);
            this.label130.TabIndex = 0;
            this.label130.Text = "0000";
            // 
            // label131
            // 
            this.label131.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(653, 235);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(29, 12);
            this.label131.TabIndex = 0;
            this.label131.Text = "0000";
            // 
            // label132
            // 
            this.label132.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(653, 256);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(29, 12);
            this.label132.TabIndex = 0;
            this.label132.Text = "0000";
            // 
            // label133
            // 
            this.label133.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(653, 277);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(29, 12);
            this.label133.TabIndex = 0;
            this.label133.Text = "0000";
            // 
            // label134
            // 
            this.label134.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(653, 298);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(29, 12);
            this.label134.TabIndex = 0;
            this.label134.Text = "0000";
            // 
            // label135
            // 
            this.label135.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(653, 319);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(29, 12);
            this.label135.TabIndex = 0;
            this.label135.Text = "0000";
            // 
            // label136
            // 
            this.label136.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(653, 340);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(29, 12);
            this.label136.TabIndex = 0;
            this.label136.Text = "0000";
            // 
            // label137
            // 
            this.label137.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(653, 361);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(29, 12);
            this.label137.TabIndex = 0;
            this.label137.Text = "0000";
            // 
            // label138
            // 
            this.label138.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(653, 382);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(29, 12);
            this.label138.TabIndex = 0;
            this.label138.Text = "0000";
            // 
            // label139
            // 
            this.label139.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(653, 403);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(29, 12);
            this.label139.TabIndex = 0;
            this.label139.Text = "0000";
            // 
            // label140
            // 
            this.label140.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(653, 428);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(29, 12);
            this.label140.TabIndex = 0;
            this.label140.Text = "0000";
            // 
            // label142
            // 
            this.label142.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(4, 46);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(17, 12);
            this.label142.TabIndex = 0;
            this.label142.Text = "02";
            // 
            // label143
            // 
            this.label143.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(4, 67);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(17, 12);
            this.label143.TabIndex = 0;
            this.label143.Text = "03";
            // 
            // label144
            // 
            this.label144.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(4, 88);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(17, 12);
            this.label144.TabIndex = 0;
            this.label144.Text = "04";
            // 
            // label145
            // 
            this.label145.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(4, 109);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(17, 12);
            this.label145.TabIndex = 0;
            this.label145.Text = "05";
            // 
            // label146
            // 
            this.label146.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(4, 130);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(17, 12);
            this.label146.TabIndex = 0;
            this.label146.Text = "06";
            // 
            // label147
            // 
            this.label147.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(4, 151);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(17, 12);
            this.label147.TabIndex = 0;
            this.label147.Text = "07";
            // 
            // label148
            // 
            this.label148.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(4, 172);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(17, 12);
            this.label148.TabIndex = 0;
            this.label148.Text = "08";
            // 
            // label149
            // 
            this.label149.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(4, 193);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(17, 12);
            this.label149.TabIndex = 0;
            this.label149.Text = "09";
            // 
            // label150
            // 
            this.label150.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(4, 214);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(17, 12);
            this.label150.TabIndex = 0;
            this.label150.Text = "10";
            // 
            // label151
            // 
            this.label151.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(4, 235);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(17, 12);
            this.label151.TabIndex = 0;
            this.label151.Text = "11";
            // 
            // label152
            // 
            this.label152.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(4, 256);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(17, 12);
            this.label152.TabIndex = 0;
            this.label152.Text = "12";
            // 
            // label153
            // 
            this.label153.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(4, 277);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(17, 12);
            this.label153.TabIndex = 0;
            this.label153.Text = "13";
            // 
            // label154
            // 
            this.label154.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(4, 298);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(17, 12);
            this.label154.TabIndex = 0;
            this.label154.Text = "14";
            // 
            // label155
            // 
            this.label155.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label155.AutoSize = true;
            this.label155.Location = new System.Drawing.Point(4, 319);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(17, 12);
            this.label155.TabIndex = 0;
            this.label155.Text = "15";
            // 
            // label156
            // 
            this.label156.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label156.AutoSize = true;
            this.label156.Location = new System.Drawing.Point(4, 340);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(17, 12);
            this.label156.TabIndex = 0;
            this.label156.Text = "16";
            // 
            // label157
            // 
            this.label157.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label157.AutoSize = true;
            this.label157.Location = new System.Drawing.Point(4, 361);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(17, 12);
            this.label157.TabIndex = 0;
            this.label157.Text = "17";
            // 
            // label158
            // 
            this.label158.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label158.AutoSize = true;
            this.label158.Location = new System.Drawing.Point(4, 382);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(17, 12);
            this.label158.TabIndex = 0;
            this.label158.Text = "18";
            // 
            // label159
            // 
            this.label159.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(4, 403);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(17, 12);
            this.label159.TabIndex = 0;
            this.label159.Text = "19";
            // 
            // label160
            // 
            this.label160.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label160.AutoSize = true;
            this.label160.Location = new System.Drawing.Point(4, 428);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(17, 12);
            this.label160.TabIndex = 0;
            this.label160.Text = "20";
            // 
            // comboBox42
            // 
            this.comboBox42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox42.FormattingEnabled = true;
            this.comboBox42.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox42.Location = new System.Drawing.Point(189, 45);
            this.comboBox42.Name = "comboBox42";
            this.comboBox42.Size = new System.Drawing.Size(47, 20);
            this.comboBox42.TabIndex = 1;
            this.comboBox42.Text = "1";
            // 
            // comboBox43
            // 
            this.comboBox43.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox43.FormattingEnabled = true;
            this.comboBox43.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox43.Location = new System.Drawing.Point(189, 66);
            this.comboBox43.Name = "comboBox43";
            this.comboBox43.Size = new System.Drawing.Size(47, 20);
            this.comboBox43.TabIndex = 1;
            this.comboBox43.Text = "1";
            // 
            // comboBox44
            // 
            this.comboBox44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox44.FormattingEnabled = true;
            this.comboBox44.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox44.Location = new System.Drawing.Point(189, 87);
            this.comboBox44.Name = "comboBox44";
            this.comboBox44.Size = new System.Drawing.Size(47, 20);
            this.comboBox44.TabIndex = 1;
            this.comboBox44.Text = "1";
            // 
            // comboBox45
            // 
            this.comboBox45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox45.FormattingEnabled = true;
            this.comboBox45.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox45.Location = new System.Drawing.Point(189, 108);
            this.comboBox45.Name = "comboBox45";
            this.comboBox45.Size = new System.Drawing.Size(47, 20);
            this.comboBox45.TabIndex = 1;
            this.comboBox45.Text = "1";
            // 
            // comboBox46
            // 
            this.comboBox46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox46.FormattingEnabled = true;
            this.comboBox46.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox46.Location = new System.Drawing.Point(189, 129);
            this.comboBox46.Name = "comboBox46";
            this.comboBox46.Size = new System.Drawing.Size(47, 20);
            this.comboBox46.TabIndex = 1;
            this.comboBox46.Text = "1";
            // 
            // comboBox47
            // 
            this.comboBox47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox47.FormattingEnabled = true;
            this.comboBox47.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox47.Location = new System.Drawing.Point(189, 150);
            this.comboBox47.Name = "comboBox47";
            this.comboBox47.Size = new System.Drawing.Size(47, 20);
            this.comboBox47.TabIndex = 1;
            this.comboBox47.Text = "1";
            // 
            // comboBox48
            // 
            this.comboBox48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox48.FormattingEnabled = true;
            this.comboBox48.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox48.Location = new System.Drawing.Point(189, 171);
            this.comboBox48.Name = "comboBox48";
            this.comboBox48.Size = new System.Drawing.Size(47, 20);
            this.comboBox48.TabIndex = 1;
            this.comboBox48.Text = "1";
            // 
            // comboBox49
            // 
            this.comboBox49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox49.FormattingEnabled = true;
            this.comboBox49.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox49.Location = new System.Drawing.Point(189, 192);
            this.comboBox49.Name = "comboBox49";
            this.comboBox49.Size = new System.Drawing.Size(47, 20);
            this.comboBox49.TabIndex = 1;
            this.comboBox49.Text = "1";
            // 
            // comboBox50
            // 
            this.comboBox50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox50.FormattingEnabled = true;
            this.comboBox50.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox50.Location = new System.Drawing.Point(189, 213);
            this.comboBox50.Name = "comboBox50";
            this.comboBox50.Size = new System.Drawing.Size(47, 20);
            this.comboBox50.TabIndex = 1;
            this.comboBox50.Text = "1";
            // 
            // comboBox51
            // 
            this.comboBox51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox51.FormattingEnabled = true;
            this.comboBox51.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox51.Location = new System.Drawing.Point(189, 234);
            this.comboBox51.Name = "comboBox51";
            this.comboBox51.Size = new System.Drawing.Size(47, 20);
            this.comboBox51.TabIndex = 1;
            this.comboBox51.Text = "1";
            // 
            // comboBox52
            // 
            this.comboBox52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox52.FormattingEnabled = true;
            this.comboBox52.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox52.Location = new System.Drawing.Point(189, 255);
            this.comboBox52.Name = "comboBox52";
            this.comboBox52.Size = new System.Drawing.Size(47, 20);
            this.comboBox52.TabIndex = 1;
            this.comboBox52.Text = "1";
            // 
            // comboBox53
            // 
            this.comboBox53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox53.FormattingEnabled = true;
            this.comboBox53.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox53.Location = new System.Drawing.Point(189, 276);
            this.comboBox53.Name = "comboBox53";
            this.comboBox53.Size = new System.Drawing.Size(47, 20);
            this.comboBox53.TabIndex = 1;
            this.comboBox53.Text = "1";
            // 
            // comboBox54
            // 
            this.comboBox54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox54.FormattingEnabled = true;
            this.comboBox54.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox54.Location = new System.Drawing.Point(189, 297);
            this.comboBox54.Name = "comboBox54";
            this.comboBox54.Size = new System.Drawing.Size(47, 20);
            this.comboBox54.TabIndex = 1;
            this.comboBox54.Text = "1";
            // 
            // comboBox55
            // 
            this.comboBox55.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox55.FormattingEnabled = true;
            this.comboBox55.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox55.Location = new System.Drawing.Point(189, 318);
            this.comboBox55.Name = "comboBox55";
            this.comboBox55.Size = new System.Drawing.Size(47, 20);
            this.comboBox55.TabIndex = 1;
            this.comboBox55.Text = "1";
            // 
            // comboBox56
            // 
            this.comboBox56.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox56.FormattingEnabled = true;
            this.comboBox56.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox56.Location = new System.Drawing.Point(189, 339);
            this.comboBox56.Name = "comboBox56";
            this.comboBox56.Size = new System.Drawing.Size(47, 20);
            this.comboBox56.TabIndex = 1;
            this.comboBox56.Text = "1";
            // 
            // comboBox57
            // 
            this.comboBox57.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox57.FormattingEnabled = true;
            this.comboBox57.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox57.Location = new System.Drawing.Point(189, 360);
            this.comboBox57.Name = "comboBox57";
            this.comboBox57.Size = new System.Drawing.Size(47, 20);
            this.comboBox57.TabIndex = 1;
            this.comboBox57.Text = "1";
            // 
            // comboBox58
            // 
            this.comboBox58.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox58.FormattingEnabled = true;
            this.comboBox58.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox58.Location = new System.Drawing.Point(189, 381);
            this.comboBox58.Name = "comboBox58";
            this.comboBox58.Size = new System.Drawing.Size(47, 20);
            this.comboBox58.TabIndex = 1;
            this.comboBox58.Text = "1";
            // 
            // comboBox59
            // 
            this.comboBox59.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox59.FormattingEnabled = true;
            this.comboBox59.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox59.Location = new System.Drawing.Point(189, 402);
            this.comboBox59.Name = "comboBox59";
            this.comboBox59.Size = new System.Drawing.Size(47, 20);
            this.comboBox59.TabIndex = 1;
            this.comboBox59.Text = "1";
            // 
            // comboBox60
            // 
            this.comboBox60.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox60.FormattingEnabled = true;
            this.comboBox60.Items.AddRange(new object[] {
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5"});
            this.comboBox60.Location = new System.Drawing.Point(189, 424);
            this.comboBox60.Name = "comboBox60";
            this.comboBox60.Size = new System.Drawing.Size(47, 20);
            this.comboBox60.TabIndex = 1;
            this.comboBox60.Text = "1";
            // 
            // labelfghhhj
            // 
            this.labelfghhhj.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelfghhhj.AutoSize = true;
            this.labelfghhhj.Location = new System.Drawing.Point(644, 4);
            this.labelfghhhj.Name = "labelfghhhj";
            this.labelfghhhj.Size = new System.Drawing.Size(47, 12);
            this.labelfghhhj.TabIndex = 0;
            this.labelfghhhj.Text = "时长(s)";
            // 
            // timerAuto
            // 
            this.timerAuto.Interval = 500;
            this.timerAuto.Tick += new System.EventHandler(this.TimerAuto_Tick);
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(718, 71);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(245, 448);
            this.listBox1.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label_chuank);
            this.groupBox1.Controls.Add(this.comboBox_StopBit);
            this.groupBox1.Controls.Add(this.comboBox_serialport);
            this.groupBox1.Controls.Add(this.labeltingzhiwei);
            this.groupBox1.Controls.Add(this.label_botelv);
            this.groupBox1.Controls.Add(this.comboBox_DataBits);
            this.groupBox1.Controls.Add(this.label_xiaoyanwei);
            this.groupBox1.Controls.Add(this.label_shujuwei);
            this.groupBox1.Controls.Add(this.comboBox_BaudRate);
            this.groupBox1.Controls.Add(this.comboBox_Parity);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(451, 53);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "串口设置";
            // 
            // buttonPath
            // 
            this.buttonPath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPath.Location = new System.Drawing.Point(884, 26);
            this.buttonPath.Name = "buttonPath";
            this.buttonPath.Size = new System.Drawing.Size(79, 23);
            this.buttonPath.TabIndex = 12;
            this.buttonPath.Text = "文件路径";
            this.buttonPath.UseVisualStyleBackColor = true;
            this.buttonPath.Click += new System.EventHandler(this.ButtonPath_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(975, 529);
            this.Controls.Add(this.buttonPath);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.button_OpenSerial);
            this.Name = "Form1";
            this.Text = "电源测试";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_OpenSerial;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Label label_chuank;
        private System.Windows.Forms.Label label_botelv;
        private System.Windows.Forms.Label label_xiaoyanwei;
        private System.Windows.Forms.Label label_shujuwei;
        private System.Windows.Forms.Label labeltingzhiwei;
        private System.Windows.Forms.ComboBox comboBox_StopBit;
        private System.Windows.Forms.ComboBox comboBox_DataBits;
        private System.Windows.Forms.ComboBox comboBox_serialport;
        private System.Windows.Forms.ComboBox comboBox_BaudRate;
        private System.Windows.Forms.ComboBox comboBox_Parity;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.CheckBox checkBoxAllS;
        private System.Windows.Forms.Label labelsdgggt;
        private System.Windows.Forms.Label labelghj;
        private System.Windows.Forms.Label labelasdffg;
        private System.Windows.Forms.Label labesdasd;
        private System.Windows.Forms.ComboBox comboBox21;
        private System.Windows.Forms.ComboBox comboBox41;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label labeliuioui;
        private System.Windows.Forms.Label labeliopiyu;
        private System.Windows.Forms.Label labelvbcbg;
        private System.Windows.Forms.Label labelgfhjgyu;
        private System.Windows.Forms.Label labelfghhhj;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labeldfgdf;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.ComboBox comboBox22;
        private System.Windows.Forms.ComboBox comboBox23;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.ComboBox comboBox27;
        private System.Windows.Forms.ComboBox comboBox28;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.ComboBox comboBox30;
        private System.Windows.Forms.ComboBox comboBox31;
        private System.Windows.Forms.ComboBox comboBox32;
        private System.Windows.Forms.ComboBox comboBox33;
        private System.Windows.Forms.ComboBox comboBox34;
        private System.Windows.Forms.ComboBox comboBox35;
        private System.Windows.Forms.ComboBox comboBox36;
        private System.Windows.Forms.ComboBox comboBox37;
        private System.Windows.Forms.ComboBox comboBox38;
        private System.Windows.Forms.ComboBox comboBox39;
        private System.Windows.Forms.ComboBox comboBox40;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.ComboBox comboBox42;
        private System.Windows.Forms.ComboBox comboBox43;
        private System.Windows.Forms.ComboBox comboBox44;
        private System.Windows.Forms.ComboBox comboBox45;
        private System.Windows.Forms.ComboBox comboBox46;
        private System.Windows.Forms.ComboBox comboBox47;
        private System.Windows.Forms.ComboBox comboBox48;
        private System.Windows.Forms.ComboBox comboBox49;
        private System.Windows.Forms.ComboBox comboBox50;
        private System.Windows.Forms.ComboBox comboBox51;
        private System.Windows.Forms.ComboBox comboBox52;
        private System.Windows.Forms.ComboBox comboBox53;
        private System.Windows.Forms.ComboBox comboBox54;
        private System.Windows.Forms.ComboBox comboBox55;
        private System.Windows.Forms.ComboBox comboBox56;
        private System.Windows.Forms.ComboBox comboBox57;
        private System.Windows.Forms.ComboBox comboBox58;
        private System.Windows.Forms.ComboBox comboBox59;
        private System.Windows.Forms.ComboBox comboBox60;
        private System.Windows.Forms.Timer timerAuto;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonPath;
    }
}

